/** @type {import('next').NextConfig} */
const nextConfig = {
   reactStrictMode: true,
   swcMinify: true,
   compiler: {
      // ssr and displayName are configured by default
      styledComponents: true,
   },
   images: {
      loader: 'imgix',
      path: '',
   },

   crossOrigin: 'anonymous',
};

module.exports = nextConfig;
