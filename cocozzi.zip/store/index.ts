import {configureStore} from '@reduxjs/toolkit';
import {useDispatch} from 'react-redux';

import authReducer from './auth/authSlice';
import cartSlice from './cart/cartSlice';
import categorySlice from './category/categorySlice';

const store = configureStore({
   reducer: {auth: authReducer, cart: cartSlice, categories: categorySlice},
});

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}

export type AppDispatch = typeof store.dispatch;
export const useAppDispatch: () => AppDispatch = useDispatch;
export default store;
