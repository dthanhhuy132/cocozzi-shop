"use strict";
(() => {
var exports = {};
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 4751:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "D2": () => (/* reexport */ ShopProduct),
  "Wg": () => (/* reexport */ ShopSliderBanner),
  "KP": () => (/* reexport */ ShopSliderProduct)
});

// UNUSED EXPORTS: Shop

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Shop/Shop.tsx

function Shop() {
    return /*#__PURE__*/ _jsx(_Fragment, {});
}

;// CONCATENATED MODULE: external "react-image-gallery"
const external_react_image_gallery_namespaceObject = require("react-image-gallery");
var external_react_image_gallery_default = /*#__PURE__*/__webpack_require__.n(external_react_image_gallery_namespaceObject);
// EXTERNAL MODULE: ./hooks/UseWindowDimensions.ts
var UseWindowDimensions = __webpack_require__(4231);
;// CONCATENATED MODULE: ./components/Shop/ShopSliderBanner.tsx



// const imgArr = [img1, img2, img3, img4, img5, img6, img7, img8];
const imgArr = [
    "/images/shop/1.webp",
    "/images/shop/2.webp",
    "/images/shop/3.webp",
    "/images/shop/4.webp",
    "/images/shop/5.webp",
    "/images/shop/6.webp",
    "/images/shop/7.webp",
    "/images/shop/8.webp", 
];
const ShopSliderBanner_images = imgArr.map((item)=>({
        original: item,
        thumbnail: item
    }));
function ShopSliderBanner() {
    const { isMobile  } = (0,UseWindowDimensions/* default */.Z)();
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_image_gallery_default()), {
        items: ShopSliderBanner_images,
        showIndex: isMobile ? true : false,
        showBullets: isMobile ? false : true,
        infinite: true,
        // autoPlay={true}
        fullscreen: true,
        showNav: true,
        showFullscreenButton: false,
        showThumbnails: false,
        showPlayButton: false,
        // onClick={(e: any) => console.log('click len cai gi', e.target)}
        additionalClass: "shop-slider"
    });
}

;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: ./components/ProductItem/index.ts + 1 modules
var ProductItem = __webpack_require__(5028);
// EXTERNAL MODULE: ./public/images/shop/1.webp
var _1 = __webpack_require__(9907);
// EXTERNAL MODULE: ./public/images/shop/2.webp
var _2 = __webpack_require__(7866);
// EXTERNAL MODULE: ./public/images/shop/3.webp
var _3 = __webpack_require__(6935);
// EXTERNAL MODULE: ./public/images/shop/4.webp
var _4 = __webpack_require__(2248);
// EXTERNAL MODULE: ./public/images/shop/5.webp
var _5 = __webpack_require__(4229);
// EXTERNAL MODULE: ./public/images/shop/6.webp
var _6 = __webpack_require__(5771);
// EXTERNAL MODULE: ./public/images/shop/7.webp
var _7 = __webpack_require__(3588);
// EXTERNAL MODULE: ./public/images/shop/8.webp
var _8 = __webpack_require__(4394);
;// CONCATENATED MODULE: ./components/Shop/ShopSliderProduct.tsx












const ShopSliderProduct_imgArr = [
    _1/* default */.Z,
    _2/* default */.Z,
    _3/* default */.Z,
    _4/* default */.Z,
    _5/* default */.Z,
    _6/* default */.Z,
    _7/* default */.Z,
    _8/* default */.Z
];
function ShopSliderProduct() {
    const { isMobile  } = (0,UseWindowDimensions/* default */.Z)();
    const settings = {
        className: "center w-full",
        infinite: true,
        centerPadding: "60px",
        slidesToShow: isMobile ? 3 : 4,
        swipeToSlide: true,
        autoplay: true,
        lazyLoad: "progressive"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
        ...settings,
        children: ShopSliderProduct_imgArr.map((img, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ProductItem/* ProductItem */.C, {
                img: img
            }, index))
    });
}

;// CONCATENATED MODULE: ./components/Shop/ShopProduct.tsx










const ShopProduct_imgArr = [
    _1/* default */.Z,
    _2/* default */.Z,
    _3/* default */.Z,
    _4/* default */.Z,
    _5/* default */.Z,
    _6/* default */.Z,
    _7/* default */.Z,
    _8/* default */.Z
];
function ShopProduct() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 md:grid-cols-4 gap-y-6 gap-x-6",
        children: ShopProduct_imgArr.map((img, index)=>/*#__PURE__*/ jsx_runtime_.jsx(ProductItem/* ProductItem */.C, {
                img: img,
                displayPrice: true
            }, index))
    });
}

;// CONCATENATED MODULE: ./components/Shop/index.ts






/***/ }),

/***/ 4231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useWindowDimensions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useWindowDimensions() {
    const hasWindow = "undefined" !== "undefined";
    function getWindowDimensions() {
        const width = hasWindow ? window.innerWidth : null;
        const height = hasWindow ? window.innerHeight : null;
        let isMobile;
        if (width && width < 600) {
            isMobile = true;
        } else {
            isMobile = false;
        }
        return {
            width,
            height,
            isMobile
        };
    }
    const { 0: windowDimensions , 1: setWindowDimensions  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getWindowDimensions());
    function handleResize() {
        setWindowDimensions(getWindowDimensions());
    }
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (hasWindow) {
            window.addEventListener("resize", handleResize);
            return ()=>window.removeEventListener("resize", handleResize);
        }
    }, [
        hasWindow
    ]);
    return windowDimensions;
}


/***/ }),

/***/ 2571:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ShopPage),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Shop__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4751);
/* harmony import */ var _service_productApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7620);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service_productApi__WEBPACK_IMPORTED_MODULE_2__]);
_service_productApi__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function ShopPage({ products =[]  }) {
    console.log("products cho nay la gi", products);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "justify-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Shop__WEBPACK_IMPORTED_MODULE_1__/* .ShopSliderBanner */ .Wg, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 mx-0 md:mx-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-[1.2rem] font-bold pl-4 md:pl-2",
                        children: "Lorem, ipsum."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Shop__WEBPACK_IMPORTED_MODULE_1__/* .ShopSliderProduct */ .KP, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-3 mt-5 text-[1.2rem] font-bold pl-4 md:pl-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "MEN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "WOMEN"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Shop__WEBPACK_IMPORTED_MODULE_1__/* .ShopProduct */ .D2, {})
                ]
            })
        ]
    });
}
const getServerSideProps = async ()=>{
    try {
        const response = await _service_productApi__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getAllProduct */ .Z.getAllProduct();
        return {
            props: {
                ok: true,
                products: response.data.data
            }
        };
    } catch (error) {
        console.log("error trong shop tra ve la gi", error);
        return {
            props: {
                ok: false
            }
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6452:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const baseURL = process.env.DEVELOPMENT_ENV;
const api = {
    call () {
        return axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
            baseURL,
            headers: {
            }
        });
    },
    callWithToken (token) {
        return axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
            baseURL,
            headers: {
                // 'Content-type': 'application/json',
                Authorization: "Bearer " + token
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (api);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7620:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const productApi = {
    getAllProduct: ({ page =1 , perPage =20  } = {})=>{
        const url = `/product/all?page=${page}&perPage=${perPage}`;
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].call */ .Z.call().get(url);
    },
    searchProduct: ()=>{
        return {};
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (productApi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [598,675,688,444], () => (__webpack_exec__(2571)));
module.exports = __webpack_exports__;

})();