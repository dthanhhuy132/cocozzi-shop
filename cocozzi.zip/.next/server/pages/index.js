"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./public/images/home/1.jpg
var _1 = __webpack_require__(4602);
// EXTERNAL MODULE: ./public/images/home/2.jpg
var _2 = __webpack_require__(7043);
// EXTERNAL MODULE: ./public/images/home/3.jpg
var _3 = __webpack_require__(8527);
// EXTERNAL MODULE: ./public/images/home/4.jpg
var _4 = __webpack_require__(7989);
;// CONCATENATED MODULE: ./components/Home/Home.tsx









const ImageArr = [
    _1/* default */.Z,
    _2/* default */.Z,
    _3/* default */.Z,
    _4/* default */.Z
];
function Home() {
    const { 0: isActiveAnimation , 1: setIsActiveAnimation  } = (0,external_react_.useState)(0);
    const router = (0,router_.useRouter)();
    const changeImageActiveAnimate = ()=>{
        if (isActiveAnimation < ImageArr.length - 1) {
            setIsActiveAnimation((pre)=>pre + 1);
        } else {
            setIsActiveAnimation(0);
        }
    };
    const handleClickImage = ()=>{
        if (router.pathname === "/") {
            router.push("/product/124");
        } else {
            return;
        }
    };
    (0,external_react_.useEffect)(()=>{
        const intervalId = setInterval(changeImageActiveAnimate, 4000);
        return ()=>clearInterval(intervalId);
    }, [
        isActiveAnimation
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-0",
        children: ImageArr.map((imageSrc, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                onClick: ()=>handleClickImage(),
                children: /*#__PURE__*/ jsx_runtime_.jsx(ImageSC, {
                    src: imageSrc,
                    active: isActiveAnimation === index ? "1" : "",
                    layout: "responsive",
                    objectFit: "cover"
                })
            }, index))
    });
}
const lighting = external_styled_components_.keyframes`
   0% {
      filter: brightness(1)
   }
   50% {
      filter: brightness(1.2)
   }
   100% {
      filter: brightness(1)
   }
`;
const ImageSC = external_styled_components_default()((image_default())).withConfig({
    componentId: "sc-b71e5a00-0"
})((props)=>external_styled_components_.css`
      animation: ${props.active && external_styled_components_.css`1s linear ${lighting}`};
      animation-timing-function: linear;
      transition: all 0.3s linear;
      transform: scale(1.01);

      cursor: pointer;
      &:hover {
         transform: scale(1.1);
         z-index: 10;
         border: 10px solid red;
         box-sizing: content-box;
      }
   `);

;// CONCATENATED MODULE: ./components/Home/index.ts


;// CONCATENATED MODULE: ./pages/index.tsx


function HomePage() {
    return /*#__PURE__*/ jsx_runtime_.jsx(Home, {});
}


/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [598,675,814], () => (__webpack_exec__(249)));
module.exports = __webpack_exports__;

})();