"use strict";
(() => {
var exports = {};
exports.id = 603;
exports.ids = [603];
exports.modules = {

/***/ 2564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SearchPage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ProductItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5028);
/* harmony import */ var _public_images_shop_1_webp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9907);
/* harmony import */ var _public_images_shop_2_webp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7866);
/* harmony import */ var _public_images_shop_3_webp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6935);
/* harmony import */ var _public_images_shop_4_webp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2248);
/* harmony import */ var _public_images_shop_5_webp__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4229);
/* harmony import */ var _public_images_shop_6_webp__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5771);
/* harmony import */ var _public_images_shop_7_webp__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3588);
/* harmony import */ var _public_images_shop_8_webp__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4394);












const imgArr = [
    _public_images_shop_1_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
    _public_images_shop_2_webp__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
    _public_images_shop_3_webp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
    _public_images_shop_4_webp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
    _public_images_shop_5_webp__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
    _public_images_shop_6_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
    _public_images_shop_7_webp__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
    _public_images_shop_8_webp__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z
];
function SearchPage() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const searchStr = router.query.q;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!searchStr) {
            router.push("/");
        }
    }, [
        searchStr
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "max-w-[1200px] flex items-center flex-col mx-[auto] my-10",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "mb-5",
                children: [
                    "Đ\xe3 t\xecm thấy 10 sản phẩm với từ kho\xe1",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "font-semibold",
                        children: [
                            " ",
                            searchStr
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-1 md:px-0 grid grid-cols-2 md:grid-cols-4 gap-x-2 gap-y-5",
                children: imgArr.map((img, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductItem__WEBPACK_IMPORTED_MODULE_3__/* .ProductItem */ .C, {
                        img: img,
                        displayPrice: true
                    }, index))
            })
        ]
    });
} // export const getServerSideProps: GetServerSideProps<any> = async (context) => {
 //    const query = context.query.q || '';
 //    try {
 //       let listProductSearch = [];
 //       return {
 //          props: {
 //             listProductSearch,
 //             error: false,
 //          },
 //       };
 //    } catch (error) {
 //       return {
 //          props: {
 //             error: true,
 //          },
 //       };
 //    }
 // };


/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [598,675,688,444], () => (__webpack_exec__(2564)));
module.exports = __webpack_exports__;

})();