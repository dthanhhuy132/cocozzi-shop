"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "$": () => (/* reexport */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Logo/index.ts + 2 modules
var Logo = __webpack_require__(9684);
;// CONCATENATED MODULE: external "react-icons/fi"
const fi_namespaceObject = require("react-icons/fi");
;// CONCATENATED MODULE: external "react-icons/im"
const im_namespaceObject = require("react-icons/im");
;// CONCATENATED MODULE: external "react-icons/io"
const io_namespaceObject = require("react-icons/io");
;// CONCATENATED MODULE: external "react-icons/si"
const si_namespaceObject = require("react-icons/si");
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/Footer/Footer.tsx








im_namespaceObject.ImFacebook;
function Footer() {
    const router = (0,router_.useRouter)();
    const hideHeaderMarquee = (0,external_react_.useMemo)(()=>{
        const excludePath = [
            "/event"
        ];
        const currentPath = router.pathname;
        return excludePath.indexOf(currentPath) === -1;
    }, [
        router.pathname
    ]);
    const adjustFooter = (0,external_react_.useMemo)(()=>{
        const includePath = [
            "/shop",
            "/promo",
            "/info",
            "/bag"
        ];
        return includePath.indexOf(router.pathname) >= 0;
    }, [
        router.pathname
    ]);
    (0,external_react_.useEffect)(()=>{
    // const script = document.createElement('script');
    // script.src = 'https://sp.zalo.me/plugins/sdk.js';
    // document.body.append(script);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `py-3 px-2 md:px-10 border-t-[1px] pt-5 ${adjustFooter ? "mt-10" : ""}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center gap-3 md:gap-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Logo/* Logo */.T, {
                        width: "120px",
                        height: "24px"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(fi_namespaceObject.FiInstagram, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(im_namespaceObject.ImFacebook, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(io_namespaceObject.IoLogoYoutube, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(si_namespaceObject.SiTiktok, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col md:flex-row gap-5 md:gap-20 mt-4 uppercase font-semibold text-[0.8rem]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "business registration number. 0314200458"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Address:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "327/6A Nguyen dinh chieu, ward 5, district 3, ho chi minh city"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "122 phan thanh, ward thac gian, thanh khe district, da nang city"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "hot line: (+84) 933 322199"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "email: info@cocozzi.vn"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "the all company limited"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "business registration no. 0317155482"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "address: 116 nguyen van thu, da cao ward, district 1, HCMC."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "hot line: (+84) 933 322199"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "email: info@theall.vn"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "zalo-chat-widget",
                "data-oaid": "665948928452952699",
                "data-welcome-message": "Rất vui khi được hỗ trợ bạn!",
                "data-autopopup": "0",
                "data-width": "300",
                "data-height": "300"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Footer/index.ts



/***/ }),

/***/ 9872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* reexport */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./components/Header/HeaderSearch.tsx





function HeaderSearch({ whiteLine =false  }) {
    const { 0: isOnInput , 1: setOnInput  } = (0,external_react_.useState)(false);
    const { 0: searchStr , 1: setSearchStr  } = (0,external_react_.useState)("");
    const router = (0,router_.useRouter)();
    const inputRef = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        if (searchStr.trim()) {
            router.push(`/search?q=${searchStr}`);
        } else if (!searchStr.trim() && router.pathname.indexOf("/search") >= 0) {
            router.push("/");
        }
    }, [
        searchStr
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-end",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DivSC, {
                isOnInput: isOnInput,
                hasSearchStr: searchStr.length > 0,
                whiteLine: whiteLine,
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "lg:block p-0 outline-none relative bg-transparent w-full",
                    onBlur: ()=>setOnInput(false),
                    onFocus: ()=>setOnInput(true),
                    onChange: (e)=>setSearchStr(e.target.value),
                    value: searchStr,
                    ref: inputRef
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "pl-2 mb-[1px]",
                children: /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsSearch, {
                    className: " -scale-x-100 cursor-pointer text-[1.4rem]",
                    onClick: ()=>inputRef.current && inputRef.current.focus()
                })
            })
        ]
    });
}
const DivSC = external_styled_components_default()("div").withConfig({
    componentId: "sc-b6ebe3e5-0"
})((props)=>`
         position: relative;

            &:before {
               content: '';
               position: absolute;
               right: 0;
               bottom: ${props.isOnInput || props.hasSearchStr ? "-2px" : "1px"};
               width: 100%;
               height: 1px;
               background: ${props.isOnInput || props.hasSearchStr ? "#999" : props.whiteLine ? "#999" : "black"};
               z-index: 99;
               transition: all ease 0.2s
            }
         `);

;// CONCATENATED MODULE: external "react-fast-marquee"
const external_react_fast_marquee_namespaceObject = require("react-fast-marquee");
var external_react_fast_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_fast_marquee_namespaceObject);
;// CONCATENATED MODULE: ./components/HeaderMarquee/HeaderMarquee.tsx



function HeaderMarquee() {
    const exampleText = [
        "Cocozzi Khuyến m\xe3i 1",
        "khuyến m\xe3i 2",
        , 
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MarqueeSC, {
        className: "relative z-10 bg-[#891b1c] ",
        speed: 50,
        direction: "left",
        pauseOnHover: "false",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: `mx-[50px] md:mx-[200px] font-bold text-white italic `,
                onClick: ()=>console.log("slffasdf"),
                children: "C\xe1ch điệu khuyến m\xe3i"
            }),
            exampleText.map((text, index)=>/*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    className: `mx-[50px] md:px-[200px] text-white hover:cursor-pointer hover:bg-red-500`,
                    children: text
                }, index)),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: `mx-[50px] md:mx-[200px] underline text-white italic`,
                children: "Khuyến m\xe3i 4 c\xf3 gạch ch\xe2n"
            })
        ]
    });
}
const MarqueeSC = external_styled_components_default()((external_react_fast_marquee_default())).withConfig({
    componentId: "sc-2b40c51e-0"
})`
   padding: 2px 0px;
   overflow: hidden;
   .overlay {
      &:before {
         background: none;
      }
      &:after {
         background: none;
      }
   }
`;

;// CONCATENATED MODULE: ./components/HeaderMarquee/index.ts


// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./components/Header/HeaderNavResponsive.tsx





const navbarHeader = [
    "shop",
    "promo",
    "event",
    "info",
    "membership"
];
const navbarHasToken = [
    "Th\xf4ng tin",
    "Trang Admin",
    "Đăng xuất"
];
function HeaderNavResponsive({ handleCloseMenu , isShowMenuRps  }) {
    const router = (0,router_.useRouter)();
    const { user  } = (0,external_react_redux_.useSelector)((state)=>state.auth);
    function handleClickNavItem(e, item) {
        e.preventDefault();
        handleCloseMenu();
        router.push(`/${item}`);
    }
    (0,external_react_.useEffect)(()=>{
        handleCloseMenu();
    }, [
        router.asPath
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `animate__animated animate__faster ${isShowMenuRps ? "animate__fadeInRight" : "animate__fadeOutRight"} fixed top-0 right-0 bottom-0 left-0 bg-black bg-opacity-90 z-50 pt-[100px] text-center text-white`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "absolute top-5 left-5 fa-sharp fa-solid fa-xmark text-[1.8rem]",
                onClick: ()=>handleCloseMenu()
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderSearch, {
                    whiteLine: true
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex justify-center gap-x-4 gap-y-3 uppercase flex-col mt-5",
                children: [
                    navbarHeader.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `hover:text-[#891b1c] font-[500] text-[1.1rem] `,
                            onClick: (e)=>handleClickNavItem(e, item),
                            children: item
                        }, item)),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "my-2 relative before:absolute before:top-0 before:left-[50%] before:translate-x-[-50%] before:w-[40px] before:h-[2px] before:bg-gray-300"
                    }),
                    navbarHasToken.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `hover:text-[#891b1c] font-[500] text-[1.1rem] `,
                            onClick: (e)=>handleClickNavItem(e, item),
                            children: item
                        }, item))
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: external "react-icons/bi"
const bi_namespaceObject = require("react-icons/bi");
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./components/Bag/index.ts + 6 modules
var Bag = __webpack_require__(9664);
// EXTERNAL MODULE: ./components/Logo/index.ts + 2 modules
var Logo = __webpack_require__(9684);
// EXTERNAL MODULE: ./hooks/UseWindowDimensions.ts
var UseWindowDimensions = __webpack_require__(4231);
;// CONCATENATED MODULE: ./components/Header/HeaderUserControl.tsx


function HeaderUserControl({ hasToken , isMobile  }) {
    const { user  } = (0,external_react_redux_.useSelector)((state)=>state.auth);
    console.log("user la gi", user);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "absolute top-7 right-[-10px] min-w-[150px] bg-white border rounded-lg shadow-[0_3px_8px_rgba(0,0,0,0.3)]",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "capitalize py-1",
            children: [
                hasToken && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "py-1 px-2 hover:bg-[#891b1c] hover:text-white cursor-pointer",
                            children: "Th\xf4ng tin"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "py-1 px-2 hover:bg-[#891b1c] hover:text-white cursor-pointer",
                            children: "Đơn h\xe0ng của t\xf4i"
                        }),
                        user.data.role === "admin" && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "py-1 px-2 hover:bg-[#891b1c] hover:text-white cursor-pointer",
                            children: "Trang Admin"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "py-1 px-2 hover:bg-[#891b1c] hover:text-white cursor-pointer",
                            children: "Đăng xuất"
                        })
                    ]
                }),
                !hasToken && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: "py-1 px-2 hover:bg-[#891b1c] hover:text-white cursor-pointer",
                    children: "Đăng nhập"
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/Header/Header.tsx















const Header_navbarHeader = [
    "shop",
    "promo",
    "event",
    "info",
    "membership"
];
function Header({ carts  }) {
    const { user  } = (0,external_react_redux_.useSelector)((state)=>state.auth);
    const router = (0,router_.useRouter)();
    const { isMobile  } = (0,UseWindowDimensions/* default */.Z)();
    const { 0: isShowMenuRps , 1: setShowMenuRps  } = (0,external_react_.useState)(false);
    const { 0: isShowBag , 1: setIsShowBag  } = (0,external_react_.useState)(false);
    const { 0: isShowUserControl , 1: setIsShowUserControl  } = (0,external_react_.useState)(false);
    const { 0: hasToken , 1: setHasToken  } = (0,external_react_.useState)(false);
    const { token  } = (0,external_react_redux_.useSelector)((state)=>state.auth);
    (0,external_react_.useEffect)(()=>{
        setHasToken(token ? true : false);
    }, [
        token
    ]);
    const hideHeaderMarquee = (0,external_react_.useMemo)(()=>{
        const excludePath = [
            "/event"
        ];
        const currentPath = router.pathname;
        return excludePath.indexOf(currentPath) === -1;
    }, [
        router.pathname
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sticky top-0 flex py-3 md:px-10 lg:flex justify-between lg:items-center z-20 bg-white border-b-[1px]",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex items-center justify-between px-2 lg:w-1/3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Logo/* Logo */.T, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "hidden lg:flex justify-center gap-x-4 gap-y-3 uppercase lg:w-1/3 flex-wrap md:gap-5 md:flex-nowrap",
                        children: Header_navbarHeader.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `/${item}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: `hover:text-[#891b1c] font-[400] text-[1.15rem] ${router.pathname === `/${item}` && "text-[#891b1c] font-[600]"}`,
                                    children: item
                                })
                            }, item))
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "px-3 flex justify-end items-center gap-x-4 uppercase lg:w-1/3 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "hidden lg:block",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(HeaderSearch, {})
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative before:absolute before:top-0 before:right-0 before:w-[50px] before:h-[40px] group cursor-pointer",
                                onMouseEnter: ()=>!isMobile && setIsShowUserControl(true),
                                onMouseLeave: ()=>!isMobile && setIsShowUserControl(false),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(bi_namespaceObject.BiUser, {
                                        fontSize: "1.6rem",
                                        className: "relative hover:text-[#891b1c] group-hover:text-[#891b1c] cursor-pointer ",
                                        onClick: ()=>{
                                            !hasToken && router.push("/membership");
                                        // isMobile && router.push('/my-order');
                                        }
                                    }),
                                    isShowUserControl && /*#__PURE__*/ jsx_runtime_.jsx(HeaderUserControl, {
                                        hasToken: hasToken,
                                        isMobile: isMobile
                                    })
                                ]
                            }),
                            hasToken && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative font-[500] hover:cursor-pointer hover:text-[#891b1c]",
                                onMouseEnter: ()=>!isMobile && setIsShowBag(true),
                                onMouseLeave: ()=>!isMobile && setIsShowBag(false),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsBag, {
                                        fontSize: "1.5rem",
                                        onClick: ()=>router.push("/bag")
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "absolute left-[50%] translate-x-[-50%] bottom-[0px] font-bold text-[#891b1c] text-[0.7rem]",
                                        onClick: ()=>router.push("/bag"),
                                        children: "68"
                                    }),
                                    isShowBag && /*#__PURE__*/ jsx_runtime_.jsx(Bag/* BagHover */.od, {})
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "lg:hidden",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineMenu, {
                                    className: " text-[1.6rem] cursor-pointer hover:text-[#891b1c]",
                                    onClick: ()=>setShowMenuRps(true)
                                })
                            })
                        ]
                    })
                ]
            }),
            hideHeaderMarquee && /*#__PURE__*/ jsx_runtime_.jsx(HeaderMarquee, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HeaderNavResponsive, {
                handleCloseMenu: ()=>setShowMenuRps(false),
                isShowMenuRps: isShowMenuRps
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Header/index.ts



/***/ }),

/***/ 5656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9872);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8062);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7544);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4664);
/* harmony import */ var _service_categoryApi__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(263);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _helper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2490);
/* harmony import */ var _service_bagApi__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store__WEBPACK_IMPORTED_MODULE_8__, _service_categoryApi__WEBPACK_IMPORTED_MODULE_9__, _helper__WEBPACK_IMPORTED_MODULE_13__, _service_bagApi__WEBPACK_IMPORTED_MODULE_14__]);
([_store__WEBPACK_IMPORTED_MODULE_8__, _service_categoryApi__WEBPACK_IMPORTED_MODULE_9__, _helper__WEBPACK_IMPORTED_MODULE_13__, _service_bagApi__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
























function MyApp({ Component , pageProps , session  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { carts , categories  } = pageProps;
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{}, []);
    // nprogress configure
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        nprogress__WEBPACK_IMPORTED_MODULE_12___default().configure({
            showSpinner: false
        });
        router.events.on("routeChangeStart", ()=>{
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().set(0.5);
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().start();
        });
        router.events.on("routeChangeComplete", ()=>{
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().done();
        });
        router.events.on("routeChangeError", ()=>{
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().done();
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_auth_react__WEBPACK_IMPORTED_MODULE_1__.SessionProvider, {
        session: session,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_7__.Provider, {
            store: _store__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                            children: "Cocozzi"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "description",
                            content: "Generated by create next app"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "icon",
                            href: "/favicon.ico"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_6___default()), {
                    src: "https://sp.zalo.me/plugins/sdk.js"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_3__/* .Header */ .h, {
                    carts: carts
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_4__/* .Footer */ .$, {})
            ]
        })
    });
}
MyApp.getInitialProps = async (appContext)=>{
    var ref, ref1;
    const [token, userToken] = (0,_helper__WEBPACK_IMPORTED_MODULE_13__/* .getTokenSSRAndCSS */ .v8)(appContext);
    const userId = userToken === null || userToken === void 0 ? void 0 : userToken.data._id;
    const appProps = await next_app__WEBPACK_IMPORTED_MODULE_5__["default"].getInitialProps(appContext);
    const allCategory = await _service_categoryApi__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getAllCategory */ .Z.getAllCategory();
    const cartRes = await _service_bagApi__WEBPACK_IMPORTED_MODULE_14__/* ["default"].getUserCart */ .Z.getUserCart(userId, token);
    const cartResData = cartRes === null || cartRes === void 0 ? void 0 : (ref = cartRes.data) === null || ref === void 0 ? void 0 : ref.data;
    const categories = allCategory === null || allCategory === void 0 ? void 0 : (ref1 = allCategory.data) === null || ref1 === void 0 ? void 0 : ref1.data;
    return {
        pageProps: {
            ...appProps.pageProps,
            categories: categories || [],
            carts: cartResData || []
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const bagApi = {
    getUserCart (userId, token) {
        if (!token || !userId) {
            return null;
        }
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].callWithToken */ .Z.callWithToken(token).get(`/cart/${userId}`);
    },
    addToCart (userId, cartItem, token) {
        if (!token || !userId) {
            return null;
        }
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].callWithToken */ .Z.callWithToken(token).post("/cart/add");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bagApi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 263:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const categoryApi = {
    getAllCategory () {
        const url = "/category/all";
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].call */ .Z.call().get(url);
    },
    getCategoryById (categoryId) {
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].call */ .Z.call().get(`/category/${categoryId}`);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (categoryApi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 887:
/***/ ((module) => {

module.exports = require("atob");

/***/ }),

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

module.exports = require("nprogress");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [598,675,676,664,217,41,688,725,765], () => (__webpack_exec__(5656)));
module.exports = __webpack_exports__;

})();