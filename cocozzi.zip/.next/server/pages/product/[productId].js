"use strict";
(() => {
var exports = {};
exports.id = 780;
exports.ids = [780];
exports.modules = {

/***/ 3429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProductDetail)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./public/images/star.png
/* harmony default export */ const star = ({"src":"/_next/static/media/star.aabba6f4.png","height":863,"width":860,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAXVBMVEX+2Bn+2Bb+2BX+2BT/1xP/1w//1wz/1gD+2BX+3GD+2Cv+2BT+2Bb+2Bb+2Bb+2BX+2BP+2BX+2BX+2BX+2BT+2BX+2BX+2BT+2BT+2BT/1xP+2BT+2BT+2BP/1xMcm9jfAAAAHHRSTlMAAAAAAAAAAAIDCAgsLj1DQ11scHB3hZWu4/n9dvNbYQAAAEJJREFUeNoFQAkSgBAAXEe6UJR78/9nNtgPhCDPDetiWjNK4X7rx/pcyJxjTGboxN6ZNITjnHQCKrIURgVpvdbeyh+SrQQedp6ZMgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./pages/product/[productId].tsx





const imageArr = [
    "/images/shop/16.webp",
    "/images/shop/17.webp",
    "/images/shop/18.webp", 
];
const SIZE = [
    "s",
    "m",
    "l",
    "xl",
    "xxl"
];
const paymentLogo = [
    "/images/logoPayment/momo.png",
    "/images/logoPayment/zalo.webp",
    "/images/logoPayment/shopee.png",
    "/images/logoPayment/vnpay.png", 
];
const customerSatisfied = [
    {
        name: "Very Good",
        reivews: 36,
        amount: 6
    },
    {
        name: "Good",
        reivews: 12,
        amount: 12
    },
    {
        name: "Normal",
        reivews: 2,
        amount: 21
    },
    {
        name: "Bad",
        reivews: 1,
        amount: 19
    },
    {
        name: "Too Bad",
        reivews: 2,
        amount: 2
    }, 
];
function ProductDetail() {
    const { 0: sizeSelect , 1: setSizeSelect  } = (0,external_react_.useState)("");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "md:px-20 lg:w-[1120px] mx-[auto] mb-[300px]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col-reverse mt-2 md:flex-row md:mt-5 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-1 gap-2 auto-rows-fr md:w-2/3 md:grid-cols-2 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("video", {
                                autoPlay: true,
                                muted: true,
                                loop: true,
                                className: "w-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("source", {
                                    src: "/videos/product.mp4",
                                    type: "video/mp4"
                                })
                            }),
                            imageArr.map((img, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "relative",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: img,
                                        layout: "fill",
                                        objectFit: "cover",
                                        alt: img
                                    })
                                }, index))
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: " w-full md:pl-5 md:top-2 md:w-[350px]",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "px-2 md:px-0 md:sticky top-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "pb-0 md:pb-5 font-semibold text-[1.2rem] ",
                                    children: "Product name Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptas, officia."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-2 pb-2 md:pb-5 flex justify-between items-center border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "font-semibold text-[1.2rem] mr-2",
                                                    children: [
                                                        456000..toLocaleString(),
                                                        " VNĐ"
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "line-through text-gray-500 text-[0.9rem]",
                                                    children: [
                                                        567000..toLocaleString(),
                                                        " VNĐ"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-[#891b1c] font-semibold text-[0.9rem] ml-2",
                                                    children: "8%"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsShare, {
                                            fontSize: "1.3rem",
                                            cursor: "pointer",
                                            className: "hover:text-[#891b1c]"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "my-2 md:mt-7",
                                    children: "Product description Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusantium ex doloribus reiciendis. Officiis possimus tempore molestias iure quaerat, doloribus quas!"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "fixed bottom-0 right-0 left-0 md:relative pb-1 md:mx-0 bg-black opacity-80 md:bg-transparent text-white md:text-black",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col gap-1 mt-2 md:mt-5 pb-2 border-b-[1px] md:pb-5",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-center md:text-left",
                                                    children: "Size"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-between mx-9 md:mx-0",
                                                    children: SIZE.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: `uppercase flex justify-center items-center cursor-pointer w-[40px] border-[1px] text-[0.9rem] p-0 md:p-1 md:px-1 ${item === sizeSelect && "bg-[#891b1c] text-white"}  `,
                                                            onClick: ()=>setSizeSelect(item),
                                                            children: item
                                                        }, index))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex flex-row justify-center gap-4 mt-2 mb-2 md:justify-start md:mt-7",
                                            children: paymentLogo.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    src: item,
                                                    className: "w-[16px] h-[16px]"
                                                }, index))
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex md:mt-3 gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "w-[50%] py-1 md:py-2 uppercase rounded-sm border-[1px] border-gray-400 hover:text-white hover:bg-black",
                                                    children: "Buy now"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "w-[50%] py-1 md:py-2 uppercase rounded-sm border-[1px] border-gray-400 hover:text-white hover:bg-black",
                                                    children: "Add to cart"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "my-10 md:my-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "px-2 md:px-[unset] uppercase text-[1.4rem] font-bold border-b-[1px] border-black",
                        children: [
                            "Reviews ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "(20)"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col md:flex-row md:gap-10 my-0 md:my-7 py-0",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col pb-5 items-center justify-center md:w-1/3 md:border-r-[1px] ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center justify-center gap-3 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: star,
                                                height: "60px",
                                                width: "60px",
                                                objectFit: "contain"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-bold text-[4rem]",
                                                children: "4.6"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-bold",
                                                children: "100%"
                                            }),
                                            " Customer like this product"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:w-2/3 px-2 flex flex-col justify-center",
                                children: customerSatisfied.map((item, index)=>{
                                    const percent = item.reivews / 40 * 100;
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "whitespace-nowrap min-w-[80px]",
                                                children: item.name
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "relative w-full bg-[#ebeff5] h-[14px] rounded-lg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `absolute top-0 left-0 bottom-0 bg-black rounded-lg`,
                                                    style: {
                                                        width: `${percent}%`
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "min-w-[20px]",
                                                children: item.reivews
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border-b-[1px] my-5 md:my-0"
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [598,675], () => (__webpack_exec__(3429)));
module.exports = __webpack_exports__;

})();