"use strict";
(() => {
var exports = {};
exports.id = 252;
exports.ids = [252];
exports.modules = {

/***/ 7786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ PaymentPage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Payment/PaymentMethod.tsx


function PaymentMethod() {
    const { 0: paymentMethod , 1: setPaymentMethod  } = (0,external_react_.useState)("cod");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "font-bold mt-6 mb-2",
                children: "PHƯƠNG THỨC THANH TO\xc1N"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "border-b-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "radio",
                                id: "momo",
                                name: "fav_language",
                                defaultValue: "momo",
                                checked: paymentMethod === "momo",
                                onChange: (e)=>setPaymentMethod(e.target.value)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "momo",
                                className: "cursor-pointer font-semibold",
                                children: "Thanh to\xe1n qua Momo"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `overflow-hidden mt-2 transition-all ${paymentMethod === "momo" ? `h-full` : "h-0"} `,
                        children: "Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 Thanh thanh to\xe1n bằng momo th\xec phải chuyển khoản trước nh\xe9 T"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "radio",
                                id: "cod",
                                name: "fav_language",
                                defaultValue: "cod",
                                checked: paymentMethod === "cod",
                                onChange: (e)=>setPaymentMethod(e.target.value)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                htmlFor: "cod",
                                className: "cursor-pointer font-semibold",
                                children: "Thanh to\xe1n khi nhận h\xe0ng"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `h-0 overflow-hidden mt-2 transition-all ${paymentMethod === "cod" && "h-[40px]"} `,
                        children: "Trả tiền mặt khi nhận h\xe0ng"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: external "react-select"
const external_react_select_namespaceObject = require("react-select");
var external_react_select_default = /*#__PURE__*/__webpack_require__.n(external_react_select_namespaceObject);
;// CONCATENATED MODULE: ./components/Payment/PaymentInputForm.tsx

function PaymetnInputForm({ label , placeHolder  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "font-[500]",
                children: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "text",
                className: "ring-1 ring-gray-300 py-[6px] px-2 rounded-[4px] outline-blue-500",
                placeholder: placeHolder
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Payment/address/address.ts
const address = [
    {
        province: "Th\xe0nh phố H\xe0 Nội",
        districtsArr: [
            "Quận Ba Đ\xecnh",
            "Quận Ho\xe0n Kiếm",
            "Quận T\xe2y Hồ",
            "Quận Long Bi\xean",
            "Quận Cầu Giấy",
            "Quận Đống Đa",
            "Quận Hai B\xe0 Trưng",
            "Quận Ho\xe0ng Mai",
            "Quận Thanh Xu\xe2n",
            "Huyện S\xf3c Sơn",
            "Huyện Đ\xf4ng Anh",
            "Huyện Gia L\xe2m",
            "Quận Nam Từ Li\xeam",
            "Huyện Thanh Tr\xec",
            "Quận Bắc Từ Li\xeam",
            "Huyện M\xea Linh",
            "Quận H\xe0 Đ\xf4ng",
            "Thị x\xe3 Sơn T\xe2y",
            "Huyện Ba V\xec",
            "Huyện Ph\xfac Thọ",
            "Huyện Đan Phượng",
            "Huyện Ho\xe0i Đức",
            "Huyện Quốc Oai",
            "Huyện Thạch Thất",
            "Huyện Chương Mỹ",
            "Huyện Thanh Oai",
            "Huyện Thường T\xedn",
            "Huyện Ph\xfa Xuy\xean",
            "Huyện Ứng H\xf2a",
            "Huyện Mỹ Đức", 
        ]
    },
    {
        province: "Tỉnh H\xe0 Giang",
        districtsArr: [
            "Th\xe0nh phố H\xe0 Giang",
            "Huyện Đồng Văn",
            "Huyện M\xe8o Vạc",
            "Huyện Y\xean Minh",
            "Huyện Quản Bạ",
            "Huyện Vị Xuy\xean",
            "Huyện Bắc M\xea",
            "Huyện Ho\xe0ng Su Ph\xec",
            "Huyện X\xedn Mần",
            "Huyện Bắc Quang",
            "Huyện Quang B\xecnh", 
        ]
    },
    {
        province: "Tỉnh Cao Bằng",
        districtsArr: [
            "Th\xe0nh phố Cao Bằng",
            "Huyện Bảo L\xe2m",
            "Huyện Bảo Lạc",
            "Huyện H\xe0 Quảng",
            "Huyện Tr\xf9ng Kh\xe1nh",
            "Huyện Hạ Lang",
            "Huyện Quảng H\xf2a",
            "Huyện Ho\xe0 An",
            "Huyện Nguy\xean B\xecnh",
            "Huyện Thạch An", 
        ]
    },
    {
        province: "Tỉnh Bắc Kạn",
        districtsArr: [
            "Th\xe0nh Phố Bắc Kạn",
            "Huyện P\xe1c Nặm",
            "Huyện Ba Bể",
            "Huyện Ng\xe2n Sơn",
            "Huyện Bạch Th\xf4ng",
            "Huyện Chợ Đồn",
            "Huyện Chợ Mới",
            "Huyện Na R\xec", 
        ]
    },
    {
        province: "Tỉnh Tuy\xean Quang",
        districtsArr: [
            "Th\xe0nh phố Tuy\xean Quang",
            "Huyện L\xe2m B\xecnh",
            "Huyện Na Hang",
            "Huyện Chi\xeam H\xf3a",
            "Huyện H\xe0m Y\xean",
            "Huyện Y\xean Sơn",
            "Huyện Sơn Dương", 
        ]
    },
    {
        province: "Tỉnh L\xe0o Cai",
        districtsArr: [
            "Th\xe0nh phố L\xe0o Cai",
            "Huyện B\xe1t X\xe1t",
            "Huyện Mường Khương",
            "Huyện Si Ma Cai",
            "Huyện Bắc H\xe0",
            "Huyện Bảo Thắng",
            "Huyện Bảo Y\xean",
            "Thị x\xe3 Sa Pa",
            "Huyện Văn B\xe0n", 
        ]
    },
    {
        province: "Tỉnh Điện Bi\xean",
        districtsArr: [
            "Th\xe0nh phố Điện Bi\xean Phủ",
            "Thị x\xe3 Mường Lay",
            "Huyện Mường Nh\xe9",
            "Huyện Mường Ch\xe0",
            "Huyện Tủa Ch\xf9a",
            "Huyện Tuần Gi\xe1o",
            "Huyện Điện Bi\xean",
            "Huyện Điện Bi\xean Đ\xf4ng",
            "Huyện Mường Ảng",
            "Huyện Nậm Pồ", 
        ]
    },
    {
        province: "Tỉnh Lai Ch\xe2u",
        districtsArr: [
            "Th\xe0nh phố Lai Ch\xe2u",
            "Huyện Tam Đường",
            "Huyện Mường T\xe8",
            "Huyện S\xecn Hồ",
            "Huyện Phong Thổ",
            "Huyện Than Uy\xean",
            "Huyện T\xe2n Uy\xean",
            "Huyện Nậm Nh\xf9n", 
        ]
    },
    {
        province: "Tỉnh Sơn La",
        districtsArr: [
            "Th\xe0nh phố Sơn La",
            "Huyện Quỳnh Nhai",
            "Huyện Thuận Ch\xe2u",
            "Huyện Mường La",
            "Huyện Bắc Y\xean",
            "Huyện Ph\xf9 Y\xean",
            "Huyện Mộc Ch\xe2u",
            "Huyện Y\xean Ch\xe2u",
            "Huyện Mai Sơn",
            "Huyện S\xf4ng M\xe3",
            "Huyện Sốp Cộp",
            "Huyện V\xe2n Hồ", 
        ]
    },
    {
        province: "Tỉnh Y\xean B\xe1i",
        districtsArr: [
            "Th\xe0nh phố Y\xean B\xe1i",
            "Thị x\xe3 Nghĩa Lộ",
            "Huyện Lục Y\xean",
            "Huyện Văn Y\xean",
            "Huyện M\xf9 Căng Chải",
            "Huyện Trấn Y\xean",
            "Huyện Trạm Tấu",
            "Huyện Văn Chấn",
            "Huyện Y\xean B\xecnh", 
        ]
    },
    {
        province: "Tỉnh Ho\xe0 B\xecnh",
        districtsArr: [
            "Th\xe0nh phố H\xf2a B\xecnh",
            "Huyện Đ\xe0 Bắc",
            "Huyện Lương Sơn",
            "Huyện Kim B\xf4i",
            "Huyện Cao Phong",
            "Huyện T\xe2n Lạc",
            "Huyện Mai Ch\xe2u",
            "Huyện Lạc Sơn",
            "Huyện Y\xean Thủy",
            "Huyện Lạc Thủy", 
        ]
    },
    {
        province: "Tỉnh Th\xe1i Nguy\xean",
        districtsArr: [
            "Th\xe0nh phố Th\xe1i Nguy\xean",
            "Th\xe0nh phố S\xf4ng C\xf4ng",
            "Huyện Định H\xf3a",
            "Huyện Ph\xfa Lương",
            "Huyện Đồng Hỷ",
            "Huyện V\xf5 Nhai",
            "Huyện Đại Từ",
            "Thị x\xe3 Phổ Y\xean",
            "Huyện Ph\xfa B\xecnh", 
        ]
    },
    {
        province: "Tỉnh Lạng Sơn",
        districtsArr: [
            "Th\xe0nh phố Lạng Sơn",
            "Huyện Tr\xe0ng Định",
            "Huyện B\xecnh Gia",
            "Huyện Văn L\xe3ng",
            "Huyện Cao Lộc",
            "Huyện Văn Quan",
            "Huyện Bắc Sơn",
            "Huyện Hữu Lũng",
            "Huyện Chi Lăng",
            "Huyện Lộc B\xecnh",
            "Huyện Đ\xecnh Lập", 
        ]
    },
    {
        province: "Tỉnh Quảng Ninh",
        districtsArr: [
            "Th\xe0nh phố Hạ Long",
            "Th\xe0nh phố M\xf3ng C\xe1i",
            "Th\xe0nh phố Cẩm Phả",
            "Th\xe0nh phố U\xf4ng B\xed",
            "Huyện B\xecnh Li\xeau",
            "Huyện Ti\xean Y\xean",
            "Huyện Đầm H\xe0",
            "Huyện Hải H\xe0",
            "Huyện Ba Chẽ",
            "Huyện V\xe2n Đồn",
            "Thị x\xe3 Đ\xf4ng Triều",
            "Thị x\xe3 Quảng Y\xean",
            "Huyện C\xf4 T\xf4", 
        ]
    },
    {
        province: "Tỉnh Bắc Giang",
        districtsArr: [
            "Th\xe0nh phố Bắc Giang",
            "Huyện Y\xean Thế",
            "Huyện T\xe2n Y\xean",
            "Huyện Lạng Giang",
            "Huyện Lục Nam",
            "Huyện Lục Ngạn",
            "Huyện Sơn Động",
            "Huyện Y\xean Dũng",
            "Huyện Việt Y\xean",
            "Huyện Hiệp H\xf2a", 
        ]
    },
    {
        province: "Tỉnh Ph\xfa Thọ",
        districtsArr: [
            "Th\xe0nh phố Việt Tr\xec",
            "Thị x\xe3 Ph\xfa Thọ",
            "Huyện Đoan H\xf9ng",
            "Huyện Hạ Ho\xe0",
            "Huyện Thanh Ba",
            "Huyện Ph\xf9 Ninh",
            "Huyện Y\xean Lập",
            "Huyện Cẩm Kh\xea",
            "Huyện Tam N\xf4ng",
            "Huyện L\xe2m Thao",
            "Huyện Thanh Sơn",
            "Huyện Thanh Thuỷ",
            "Huyện T\xe2n Sơn", 
        ]
    },
    {
        province: "Tỉnh Vĩnh Ph\xfac",
        districtsArr: [
            "Th\xe0nh phố Vĩnh Y\xean",
            "Th\xe0nh phố Ph\xfac Y\xean",
            "Huyện Lập Thạch",
            "Huyện Tam Dương",
            "Huyện Tam Đảo",
            "Huyện B\xecnh Xuy\xean",
            "Huyện Y\xean Lạc",
            "Huyện Vĩnh Tường",
            "Huyện S\xf4ng L\xf4", 
        ]
    },
    {
        province: "Tỉnh Bắc Ninh",
        districtsArr: [
            "Th\xe0nh phố Bắc Ninh",
            "Huyện Y\xean Phong",
            "Huyện Quế V\xf5",
            "Huyện Ti\xean Du",
            "Thị x\xe3 Từ Sơn",
            "Huyện Thuận Th\xe0nh",
            "Huyện Gia B\xecnh",
            "Huyện Lương T\xe0i", 
        ]
    },
    {
        province: "Tỉnh Hải Dương",
        districtsArr: [
            "Th\xe0nh phố Hải Dương",
            "Th\xe0nh phố Ch\xed Linh",
            "Huyện Nam S\xe1ch",
            "Thị x\xe3 Kinh M\xf4n",
            "Huyện Kim Th\xe0nh",
            "Huyện Thanh H\xe0",
            "Huyện Cẩm Gi\xe0ng",
            "Huyện B\xecnh Giang",
            "Huyện Gia Lộc",
            "Huyện Tứ Kỳ",
            "Huyện Ninh Giang",
            "Huyện Thanh Miện", 
        ]
    },
    {
        province: "Th\xe0nh phố Hải Ph\xf2ng",
        districtsArr: [
            "Quận Hồng B\xe0ng",
            "Quận Ng\xf4 Quyền",
            "Quận L\xea Ch\xe2n",
            "Quận Hải An",
            "Quận Kiến An",
            "Quận Đồ Sơn",
            "Quận Dương Kinh",
            "Huyện Thuỷ Nguy\xean",
            "Huyện An Dương",
            "Huyện An L\xe3o",
            "Huyện Kiến Thuỵ",
            "Huyện Ti\xean L\xe3ng",
            "Huyện Vĩnh Bảo",
            "Huyện C\xe1t Hải",
            "Huyện Bạch Long Vĩ", 
        ]
    },
    {
        province: "Tỉnh Hưng Y\xean",
        districtsArr: [
            "Th\xe0nh phố Hưng Y\xean",
            "Huyện Văn L\xe2m",
            "Huyện Văn Giang",
            "Huyện Y\xean Mỹ",
            "Thị x\xe3 Mỹ H\xe0o",
            "Huyện \xc2n Thi",
            "Huyện Kho\xe1i Ch\xe2u",
            "Huyện Kim Động",
            "Huyện Ti\xean Lữ",
            "Huyện Ph\xf9 Cừ", 
        ]
    },
    {
        province: "Tỉnh Th\xe1i B\xecnh",
        districtsArr: [
            "Th\xe0nh phố Th\xe1i B\xecnh",
            "Huyện Quỳnh Phụ",
            "Huyện Hưng H\xe0",
            "Huyện Đ\xf4ng Hưng",
            "Huyện Th\xe1i Thụy",
            "Huyện Tiền Hải",
            "Huyện Kiến Xương",
            "Huyện Vũ Thư", 
        ]
    },
    {
        province: "Tỉnh H\xe0 Nam",
        districtsArr: [
            "Th\xe0nh phố Phủ L\xfd",
            "Thị x\xe3 Duy Ti\xean",
            "Huyện Kim Bảng",
            "Huyện Thanh Li\xeam",
            "Huyện B\xecnh Lục",
            "Huyện L\xfd Nh\xe2n", 
        ]
    },
    {
        province: "Tỉnh Nam Định",
        districtsArr: [
            "Th\xe0nh phố Nam Định",
            "Huyện Mỹ Lộc",
            "Huyện Vụ Bản",
            "Huyện \xdd Y\xean",
            "Huyện Nghĩa Hưng",
            "Huyện Nam Trực",
            "Huyện Trực Ninh",
            "Huyện Xu\xe2n Trường",
            "Huyện Giao Thủy",
            "Huyện Hải Hậu", 
        ]
    },
    {
        province: "Tỉnh Ninh B\xecnh",
        districtsArr: [
            "Th\xe0nh phố Ninh B\xecnh",
            "Th\xe0nh phố Tam Điệp",
            "Huyện Nho Quan",
            "Huyện Gia Viễn",
            "Huyện Hoa Lư",
            "Huyện Y\xean Kh\xe1nh",
            "Huyện Kim Sơn",
            "Huyện Y\xean M\xf4", 
        ]
    },
    {
        province: "Tỉnh Thanh H\xf3a",
        districtsArr: [
            "Th\xe0nh phố Thanh H\xf3a",
            "Thị x\xe3 Bỉm Sơn",
            "Th\xe0nh phố Sầm Sơn",
            "Huyện Mường L\xe1t",
            "Huyện Quan H\xf3a",
            "Huyện B\xe1 Thước",
            "Huyện Quan Sơn",
            "Huyện Lang Ch\xe1nh",
            "Huyện Ngọc Lặc",
            "Huyện Cẩm Thủy",
            "Huyện Thạch Th\xe0nh",
            "Huyện H\xe0 Trung",
            "Huyện Vĩnh Lộc",
            "Huyện Y\xean Định",
            "Huyện Thọ Xu\xe2n",
            "Huyện Thường Xu\xe2n",
            "Huyện Triệu Sơn",
            "Huyện Thiệu H\xf3a",
            "Huyện Hoằng H\xf3a",
            "Huyện Hậu Lộc",
            "Huyện Nga Sơn",
            "Huyện Như Xu\xe2n",
            "Huyện Như Thanh",
            "Huyện N\xf4ng Cống",
            "Huyện Đ\xf4ng Sơn",
            "Huyện Quảng Xương",
            "Thị x\xe3 Nghi Sơn", 
        ]
    },
    {
        province: "Tỉnh Nghệ An",
        districtsArr: [
            "Th\xe0nh phố Vinh",
            "Thị x\xe3 Cửa L\xf2",
            "Thị x\xe3 Th\xe1i Ho\xe0",
            "Huyện Quế Phong",
            "Huyện Quỳ Ch\xe2u",
            "Huyện Kỳ Sơn",
            "Huyện Tương Dương",
            "Huyện Nghĩa Đ\xe0n",
            "Huyện Quỳ Hợp",
            "Huyện Quỳnh Lưu",
            "Huyện Con Cu\xf4ng",
            "Huyện T\xe2n Kỳ",
            "Huyện Anh Sơn",
            "Huyện Diễn Ch\xe2u",
            "Huyện Y\xean Th\xe0nh",
            "Huyện Đ\xf4 Lương",
            "Huyện Thanh Chương",
            "Huyện Nghi Lộc",
            "Huyện Nam Đ\xe0n",
            "Huyện Hưng Nguy\xean",
            "Thị x\xe3 Ho\xe0ng Mai", 
        ]
    },
    {
        province: "Tỉnh H\xe0 Tĩnh",
        districtsArr: [
            "Th\xe0nh phố H\xe0 Tĩnh",
            "Thị x\xe3 Hồng Lĩnh",
            "Huyện Hương Sơn",
            "Huyện Đức Thọ",
            "Huyện Vũ Quang",
            "Huyện Nghi Xu\xe2n",
            "Huyện Can Lộc",
            "Huyện Hương Kh\xea",
            "Huyện Thạch H\xe0",
            "Huyện Cẩm Xuy\xean",
            "Huyện Kỳ Anh",
            "Huyện Lộc H\xe0",
            "Thị x\xe3 Kỳ Anh", 
        ]
    },
    {
        province: "Tỉnh Quảng B\xecnh",
        districtsArr: [
            "Th\xe0nh Phố Đồng Hới",
            "Huyện Minh H\xf3a",
            "Huyện Tuy\xean H\xf3a",
            "Huyện Quảng Trạch",
            "Huyện Bố Trạch",
            "Huyện Quảng Ninh",
            "Huyện Lệ Thủy",
            "Thị x\xe3 Ba Đồn", 
        ]
    },
    {
        province: "Tỉnh Quảng Trị",
        districtsArr: [
            "Th\xe0nh phố Đ\xf4ng H\xe0",
            "Thị x\xe3 Quảng Trị",
            "Huyện Vĩnh Linh",
            "Huyện Hướng H\xf3a",
            "Huyện Gio Linh",
            "Huyện Đa Kr\xf4ng",
            "Huyện Cam Lộ",
            "Huyện Triệu Phong",
            "Huyện Hải Lăng",
            "Huyện Cồn Cỏ", 
        ]
    },
    {
        province: "Tỉnh Thừa Thi\xean Huế",
        districtsArr: [
            "Th\xe0nh phố Huế",
            "Huyện Phong Điền",
            "Huyện Quảng Điền",
            "Huyện Ph\xfa Vang",
            "Thị x\xe3 Hương Thủy",
            "Thị x\xe3 Hương Tr\xe0",
            "Huyện A Lưới",
            "Huyện Ph\xfa Lộc",
            "Huyện Nam Đ\xf4ng", 
        ]
    },
    {
        province: "Th\xe0nh phố Đ\xe0 Nẵng",
        districtsArr: [
            "Quận Li\xean Chiểu",
            "Quận Thanh Kh\xea",
            "Quận Hải Ch\xe2u",
            "Quận Sơn Tr\xe0",
            "Quận Ngũ H\xe0nh Sơn",
            "Quận Cẩm Lệ",
            "Huyện H\xf2a Vang",
            "Huyện Ho\xe0ng Sa", 
        ]
    },
    {
        province: "Tỉnh Quảng Nam",
        districtsArr: [
            "Th\xe0nh phố Tam Kỳ",
            "Th\xe0nh phố Hội An",
            "Huyện T\xe2y Giang",
            "Huyện Đ\xf4ng Giang",
            "Huyện Đại Lộc",
            "Thị x\xe3 Điện B\xe0n",
            "Huyện Duy Xuy\xean",
            "Huyện Quế Sơn",
            "Huyện Nam Giang",
            "Huyện Phước Sơn",
            "Huyện Hiệp Đức",
            "Huyện Thăng B\xecnh",
            "Huyện Ti\xean Phước",
            "Huyện Bắc Tr\xe0 My",
            "Huyện Nam Tr\xe0 My",
            "Huyện N\xfai Th\xe0nh",
            "Huyện Ph\xfa Ninh",
            "Huyện N\xf4ng Sơn", 
        ]
    },
    {
        province: "Tỉnh Quảng Ng\xe3i",
        districtsArr: [
            "Th\xe0nh phố Quảng Ng\xe3i",
            "Huyện B\xecnh Sơn",
            "Huyện Tr\xe0 Bồng",
            "Huyện Sơn Tịnh",
            "Huyện Tư Nghĩa",
            "Huyện Sơn H\xe0",
            "Huyện Sơn T\xe2y",
            "Huyện Minh Long",
            "Huyện Nghĩa H\xe0nh",
            "Huyện Mộ Đức",
            "Thị x\xe3 Đức Phổ",
            "Huyện Ba Tơ",
            "Huyện L\xfd Sơn", 
        ]
    },
    {
        province: "Tỉnh B\xecnh Định",
        districtsArr: [
            "Th\xe0nh phố Quy Nhơn",
            "Huyện An L\xe3o",
            "Thị x\xe3 Ho\xe0i Nhơn",
            "Huyện Ho\xe0i \xc2n",
            "Huyện Ph\xf9 Mỹ",
            "Huyện Vĩnh Thạnh",
            "Huyện T\xe2y Sơn",
            "Huyện Ph\xf9 C\xe1t",
            "Thị x\xe3 An Nhơn",
            "Huyện Tuy Phước",
            "Huyện V\xe2n Canh", 
        ]
    },
    {
        province: "Tỉnh Ph\xfa Y\xean",
        districtsArr: [
            "Th\xe0nh phố Tuy Ho\xe0",
            "Thị x\xe3 S\xf4ng Cầu",
            "Huyện Đồng Xu\xe2n",
            "Huyện Tuy An",
            "Huyện Sơn H\xf2a",
            "Huyện S\xf4ng Hinh",
            "Huyện T\xe2y Ho\xe0",
            "Huyện Ph\xfa Ho\xe0",
            "Thị x\xe3 Đ\xf4ng H\xf2a", 
        ]
    },
    {
        province: "Tỉnh Kh\xe1nh H\xf2a",
        districtsArr: [
            "Th\xe0nh phố Nha Trang",
            "Th\xe0nh phố Cam Ranh",
            "Huyện Cam L\xe2m",
            "Huyện Vạn Ninh",
            "Thị x\xe3 Ninh H\xf2a",
            "Huyện Kh\xe1nh Vĩnh",
            "Huyện Di\xean Kh\xe1nh",
            "Huyện Kh\xe1nh Sơn",
            "Huyện Trường Sa", 
        ]
    },
    {
        province: "Tỉnh Ninh Thuận",
        districtsArr: [
            "Th\xe0nh phố Phan Rang-Th\xe1p Ch\xe0m",
            "Huyện B\xe1c \xc1i",
            "Huyện Ninh Sơn",
            "Huyện Ninh Hải",
            "Huyện Ninh Phước",
            "Huyện Thuận Bắc",
            "Huyện Thuận Nam", 
        ]
    },
    {
        province: "Tỉnh B\xecnh Thuận",
        districtsArr: [
            "Th\xe0nh phố Phan Thiết",
            "Thị x\xe3 La Gi",
            "Huyện Tuy Phong",
            "Huyện Bắc B\xecnh",
            "Huyện H\xe0m Thuận Bắc",
            "Huyện H\xe0m Thuận Nam",
            "Huyện T\xe1nh Linh",
            "Huyện Đức Linh",
            "Huyện H\xe0m T\xe2n",
            "Huyện Ph\xfa Qu\xed", 
        ]
    },
    {
        province: "Tỉnh Kon Tum",
        districtsArr: [
            "Th\xe0nh phố Kon Tum",
            "Huyện Đắk Glei",
            "Huyện Ngọc Hồi",
            "Huyện Đắk T\xf4",
            "Huyện Kon Pl\xf4ng",
            "Huyện Kon Rẫy",
            "Huyện Đắk H\xe0",
            "Huyện Sa Thầy",
            "Huyện Tu Mơ R\xf4ng",
            "Huyện Ia H' Drai", 
        ]
    },
    {
        province: "Tỉnh Gia Lai",
        districtsArr: [
            "Th\xe0nh phố Pleiku",
            "Thị x\xe3 An Kh\xea",
            "Thị x\xe3 Ayun Pa",
            "Huyện KBang",
            "Huyện Đăk Đoa",
            "Huyện Chư Păh",
            "Huyện Ia Grai",
            "Huyện Mang Yang",
            "Huyện K\xf4ng Chro",
            "Huyện Đức Cơ",
            "Huyện Chư Pr\xf4ng",
            "Huyện Chư S\xea",
            "Huyện Đăk Pơ",
            "Huyện Ia Pa",
            "Huyện Kr\xf4ng Pa",
            "Huyện Ph\xfa Thiện",
            "Huyện Chư Pưh", 
        ]
    },
    {
        province: "Tỉnh Đắk Lắk",
        districtsArr: [
            "Th\xe0nh phố Bu\xf4n Ma Thuột",
            "Thị x\xe3 Bu\xf4n Hồ",
            "Huyện Ea H'leo",
            "Huyện Ea S\xfap",
            "Huyện Bu\xf4n Đ\xf4n",
            "Huyện Cư M'gar",
            "Huyện Kr\xf4ng B\xfak",
            "Huyện Kr\xf4ng Năng",
            "Huyện Ea Kar",
            "Huyện M'Đrắk",
            "Huyện Kr\xf4ng B\xf4ng",
            "Huyện Kr\xf4ng Pắc",
            "Huyện Kr\xf4ng A Na",
            "Huyện Lắk",
            "Huyện Cư Kuin", 
        ]
    },
    {
        province: "Tỉnh Đắk N\xf4ng",
        districtsArr: [
            "Th\xe0nh phố Gia Nghĩa",
            "Huyện Đăk Glong",
            "Huyện Cư J\xfat",
            "Huyện Đắk Mil",
            "Huyện Kr\xf4ng N\xf4",
            "Huyện Đắk Song",
            "Huyện Đắk R'Lấp",
            "Huyện Tuy Đức", 
        ]
    },
    {
        province: "Tỉnh L\xe2m Đồng",
        districtsArr: [
            "Th\xe0nh phố Đ\xe0 Lạt",
            "Th\xe0nh phố Bảo Lộc",
            "Huyện Đam R\xf4ng",
            "Huyện Lạc Dương",
            "Huyện L\xe2m H\xe0",
            "Huyện Đơn Dương",
            "Huyện Đức Trọng",
            "Huyện Di Linh",
            "Huyện Bảo L\xe2m",
            "Huyện Đạ Huoai",
            "Huyện Đạ Tẻh",
            "Huyện C\xe1t Ti\xean", 
        ]
    },
    {
        province: "Tỉnh B\xecnh Phước",
        districtsArr: [
            "Thị x\xe3 Phước Long",
            "Th\xe0nh phố Đồng Xo\xe0i",
            "Thị x\xe3 B\xecnh Long",
            "Huyện B\xf9 Gia Mập",
            "Huyện Lộc Ninh",
            "Huyện B\xf9 Đốp",
            "Huyện Hớn Quản",
            "Huyện Đồng Ph\xfa",
            "Huyện B\xf9 Đăng",
            "Huyện Chơn Th\xe0nh",
            "Huyện Ph\xfa Riềng", 
        ]
    },
    {
        province: "Tỉnh T\xe2y Ninh",
        districtsArr: [
            "Th\xe0nh phố T\xe2y Ninh",
            "Huyện T\xe2n Bi\xean",
            "Huyện T\xe2n Ch\xe2u",
            "Huyện Dương Minh Ch\xe2u",
            "Huyện Ch\xe2u Th\xe0nh",
            "Thị x\xe3 H\xf2a Th\xe0nh",
            "Huyện G\xf2 Dầu",
            "Huyện Bến Cầu",
            "Thị x\xe3 Trảng B\xe0ng", 
        ]
    },
    {
        province: "Tỉnh B\xecnh Dương",
        districtsArr: [
            "Th\xe0nh phố Thủ Dầu Một",
            "Huyện B\xe0u B\xe0ng",
            "Huyện Dầu Tiếng",
            "Thị x\xe3 Bến C\xe1t",
            "Huyện Ph\xfa Gi\xe1o",
            "Thị x\xe3 T\xe2n Uy\xean",
            "Th\xe0nh phố Dĩ An",
            "Th\xe0nh phố Thuận An",
            "Huyện Bắc T\xe2n Uy\xean", 
        ]
    },
    {
        province: "Tỉnh Đồng Nai",
        districtsArr: [
            "Th\xe0nh phố Bi\xean H\xf2a",
            "Th\xe0nh phố Long Kh\xe1nh",
            "Huyện T\xe2n Ph\xfa",
            "Huyện Vĩnh Cửu",
            "Huyện Định Qu\xe1n",
            "Huyện Trảng Bom",
            "Huyện Thống Nhất",
            "Huyện Cẩm Mỹ",
            "Huyện Long Th\xe0nh",
            "Huyện Xu\xe2n Lộc",
            "Huyện Nhơn Trạch", 
        ]
    },
    {
        province: "Tỉnh B\xe0 Rịa - Vũng T\xe0u",
        districtsArr: [
            "Th\xe0nh phố Vũng T\xe0u",
            "Th\xe0nh phố B\xe0 Rịa",
            "Huyện Ch\xe2u Đức",
            "Huyện Xuy\xean Mộc",
            "Huyện Long Điền",
            "Huyện Đất Đỏ",
            "Thị x\xe3 Ph\xfa Mỹ",
            "Huyện C\xf4n Đảo", 
        ]
    },
    {
        province: "Th\xe0nh phố Hồ Ch\xed Minh",
        districtsArr: [
            "Quận 1",
            "Quận 12",
            "Quận G\xf2 Vấp",
            "Quận B\xecnh Thạnh",
            "Quận T\xe2n B\xecnh",
            "Quận T\xe2n Ph\xfa",
            "Quận Ph\xfa Nhuận",
            "Th\xe0nh phố Thủ Đức",
            "Quận 3",
            "Quận 10",
            "Quận 11",
            "Quận 4",
            "Quận 5",
            "Quận 6",
            "Quận 8",
            "Quận B\xecnh T\xe2n",
            "Quận 7",
            "Huyện Củ Chi",
            "Huyện H\xf3c M\xf4n",
            "Huyện B\xecnh Ch\xe1nh",
            "Huyện Nh\xe0 B\xe8",
            "Huyện Cần Giờ", 
        ]
    },
    {
        province: "Tỉnh Long An",
        districtsArr: [
            "Th\xe0nh phố T\xe2n An",
            "Thị x\xe3 Kiến Tường",
            "Huyện T\xe2n Hưng",
            "Huyện Vĩnh Hưng",
            "Huyện Mộc H\xf3a",
            "Huyện T\xe2n Thạnh",
            "Huyện Thạnh H\xf3a",
            "Huyện Đức Huệ",
            "Huyện Đức H\xf2a",
            "Huyện Bến Lức",
            "Huyện Thủ Thừa",
            "Huyện T\xe2n Trụ",
            "Huyện Cần Đước",
            "Huyện Cần Giuộc",
            "Huyện Ch\xe2u Th\xe0nh", 
        ]
    },
    {
        province: "Tỉnh Tiền Giang",
        districtsArr: [
            "Th\xe0nh phố Mỹ Tho",
            "Thị x\xe3 G\xf2 C\xf4ng",
            "Thị x\xe3 Cai Lậy",
            "Huyện T\xe2n Phước",
            "Huyện C\xe1i B\xe8",
            "Huyện Cai Lậy",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Chợ Gạo",
            "Huyện G\xf2 C\xf4ng T\xe2y",
            "Huyện G\xf2 C\xf4ng Đ\xf4ng",
            "Huyện T\xe2n Ph\xfa Đ\xf4ng", 
        ]
    },
    {
        province: "Tỉnh Bến Tre",
        districtsArr: [
            "Th\xe0nh phố Bến Tre",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Chợ L\xe1ch",
            "Huyện Mỏ C\xe0y Nam",
            "Huyện Giồng Tr\xf4m",
            "Huyện B\xecnh Đại",
            "Huyện Ba Tri",
            "Huyện Thạnh Ph\xfa",
            "Huyện Mỏ C\xe0y Bắc", 
        ]
    },
    {
        province: "Tỉnh Tr\xe0 Vinh",
        districtsArr: [
            "Th\xe0nh phố Tr\xe0 Vinh",
            "Huyện C\xe0ng Long",
            "Huyện Cầu K\xe8",
            "Huyện Tiểu Cần",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Cầu Ngang",
            "Huyện Tr\xe0 C\xfa",
            "Huyện Duy\xean Hải",
            "Thị x\xe3 Duy\xean Hải", 
        ]
    },
    {
        province: "Tỉnh Vĩnh Long",
        districtsArr: [
            "Th\xe0nh phố Vĩnh Long",
            "Huyện Long Hồ",
            "Huyện Mang Th\xedt",
            "Huyện Vũng Li\xeam",
            "Huyện Tam B\xecnh",
            "Thị x\xe3 B\xecnh Minh",
            "Huyện Tr\xe0 \xd4n",
            "Huyện B\xecnh T\xe2n", 
        ]
    },
    {
        province: "Tỉnh Đồng Th\xe1p",
        districtsArr: [
            "Th\xe0nh phố Cao L\xe3nh",
            "Th\xe0nh phố Sa Đ\xe9c",
            "Th\xe0nh phố Hồng Ngự",
            "Huyện T\xe2n Hồng",
            "Huyện Hồng Ngự",
            "Huyện Tam N\xf4ng",
            "Huyện Th\xe1p Mười",
            "Huyện Cao L\xe3nh",
            "Huyện Thanh B\xecnh",
            "Huyện Lấp V\xf2",
            "Huyện Lai Vung",
            "Huyện Ch\xe2u Th\xe0nh", 
        ]
    },
    {
        province: "Tỉnh An Giang",
        districtsArr: [
            "Th\xe0nh phố Long Xuy\xean",
            "Th\xe0nh phố Ch\xe2u Đốc",
            "Huyện An Ph\xfa",
            "Thị x\xe3 T\xe2n Ch\xe2u",
            "Huyện Ph\xfa T\xe2n",
            "Huyện Ch\xe2u Ph\xfa",
            "Huyện Tịnh Bi\xean",
            "Huyện Tri T\xf4n",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Chợ Mới",
            "Huyện Thoại Sơn", 
        ]
    },
    {
        province: "Tỉnh Ki\xean Giang",
        districtsArr: [
            "Th\xe0nh phố Rạch Gi\xe1",
            "Th\xe0nh phố H\xe0 Ti\xean",
            "Huyện Ki\xean Lương",
            "Huyện H\xf2n Đất",
            "Huyện T\xe2n Hiệp",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Giồng Riềng",
            "Huyện G\xf2 Quao",
            "Huyện An Bi\xean",
            "Huyện An Minh",
            "Huyện Vĩnh Thuận",
            "Th\xe0nh phố Ph\xfa Quốc",
            "Huyện Ki\xean Hải",
            "Huyện U Minh Thượng",
            "Huyện Giang Th\xe0nh", 
        ]
    },
    {
        province: "Th\xe0nh phố Cần Thơ",
        districtsArr: [
            "Quận Ninh Kiều",
            "Quận \xd4 M\xf4n",
            "Quận B\xecnh Thuỷ",
            "Quận C\xe1i Răng",
            "Quận Thốt Nốt",
            "Huyện Vĩnh Thạnh",
            "Huyện Cờ Đỏ",
            "Huyện Phong Điền",
            "Huyện Thới Lai", 
        ]
    },
    {
        province: "Tỉnh Hậu Giang",
        districtsArr: [
            "Th\xe0nh phố Vị Thanh",
            "Th\xe0nh phố Ng\xe3 Bảy",
            "Huyện Ch\xe2u Th\xe0nh A",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Phụng Hiệp",
            "Huyện Vị Thuỷ",
            "Huyện Long Mỹ",
            "Thị x\xe3 Long Mỹ", 
        ]
    },
    {
        province: "Tỉnh S\xf3c Trăng",
        districtsArr: [
            "Th\xe0nh phố S\xf3c Trăng",
            "Huyện Ch\xe2u Th\xe0nh",
            "Huyện Kế S\xe1ch",
            "Huyện Mỹ T\xfa",
            "Huyện C\xf9 Lao Dung",
            "Huyện Long Ph\xfa",
            "Huyện Mỹ Xuy\xean",
            "Thị x\xe3 Ng\xe3 Năm",
            "Huyện Thạnh Trị",
            "Thị x\xe3 Vĩnh Ch\xe2u",
            "Huyện Trần Đề", 
        ]
    },
    {
        province: "Tỉnh Bạc Li\xeau",
        districtsArr: [
            "Th\xe0nh phố Bạc Li\xeau",
            "Huyện Hồng D\xe2n",
            "Huyện Phước Long",
            "Huyện Vĩnh Lợi",
            "Thị x\xe3 Gi\xe1 Rai",
            "Huyện Đ\xf4ng Hải",
            "Huyện Ho\xe0 B\xecnh", 
        ]
    },
    {
        province: "Tỉnh C\xe0 Mau",
        districtsArr: [
            "Th\xe0nh phố C\xe0 Mau",
            "Huyện U Minh",
            "Huyện Thới B\xecnh",
            "Huyện Trần Văn Thời",
            "Huyện C\xe1i Nước",
            "Huyện Đầm Dơi",
            "Huyện Năm Căn",
            "Huyện Ph\xfa T\xe2n",
            "Huyện Ngọc Hiển", 
        ]
    }, 
];

;// CONCATENATED MODULE: ./components/Payment/address/province.ts
const province = [
    "Th\xe0nh phố H\xe0 Nội",
    "Tỉnh H\xe0 Giang",
    "Tỉnh Cao Bằng",
    "Tỉnh Bắc Kạn",
    "Tỉnh Tuy\xean Quang",
    "Tỉnh L\xe0o Cai",
    "Tỉnh Điện Bi\xean",
    "Tỉnh Lai Ch\xe2u",
    "Tỉnh Sơn La",
    "Tỉnh Y\xean B\xe1i",
    "Tỉnh Ho\xe0 B\xecnh",
    "Tỉnh Th\xe1i Nguy\xean",
    "Tỉnh Lạng Sơn",
    "Tỉnh Quảng Ninh",
    "Tỉnh Bắc Giang",
    "Tỉnh Ph\xfa Thọ",
    "Tỉnh Vĩnh Ph\xfac",
    "Tỉnh Bắc Ninh",
    "Tỉnh Hải Dương",
    "Th\xe0nh phố Hải Ph\xf2ng",
    "Tỉnh Hưng Y\xean",
    "Tỉnh Th\xe1i B\xecnh",
    "Tỉnh H\xe0 Nam",
    "Tỉnh Nam Định",
    "Tỉnh Ninh B\xecnh",
    "Tỉnh Thanh H\xf3a",
    "Tỉnh Nghệ An",
    "Tỉnh H\xe0 Tĩnh",
    "Tỉnh Quảng B\xecnh",
    "Tỉnh Quảng Trị",
    "Tỉnh Thừa Thi\xean Huế",
    "Th\xe0nh phố Đ\xe0 Nẵng",
    "Tỉnh Quảng Nam",
    "Tỉnh Quảng Ng\xe3i",
    "Tỉnh B\xecnh Định",
    "Tỉnh Ph\xfa Y\xean",
    "Tỉnh Kh\xe1nh H\xf2a",
    "Tỉnh Ninh Thuận",
    "Tỉnh B\xecnh Thuận",
    "Tỉnh Kon Tum",
    "Tỉnh Gia Lai",
    "Tỉnh Đắk Lắk",
    "Tỉnh Đắk N\xf4ng",
    "Tỉnh L\xe2m Đồng",
    "Tỉnh B\xecnh Phước",
    "Tỉnh T\xe2y Ninh",
    "Tỉnh B\xecnh Dương",
    "Tỉnh Đồng Nai",
    "Tỉnh B\xe0 Rịa - Vũng T\xe0u",
    "Th\xe0nh phố Hồ Ch\xed Minh",
    "Tỉnh Long An",
    "Tỉnh Tiền Giang",
    "Tỉnh Bến Tre",
    "Tỉnh Tr\xe0 Vinh",
    "Tỉnh Vĩnh Long",
    "Tỉnh Đồng Th\xe1p",
    "Tỉnh An Giang",
    "Tỉnh Ki\xean Giang",
    "Th\xe0nh phố Cần Thơ",
    "Tỉnh Hậu Giang",
    "Tỉnh S\xf3c Trăng",
    "Tỉnh Bạc Li\xeau",
    "Tỉnh C\xe0 Mau", 
];

;// CONCATENATED MODULE: ./components/Payment/PaymentAddress.tsx






function PaymentAddress() {
    const formatProvince = province.map((item)=>({
            value: item,
            label: item
        }));
    const { 0: initProvince , 1: setProvince  } = (0,external_react_.useState)("Th\xe0nh phố Hồ Ch\xed Minh");
    const { 0: districtName , 1: setDistrictName  } = (0,external_react_.useState)("");
    const { 0: district , 1: setDistrict  } = (0,external_react_.useState)([]);
    function getAndFormatDistrict() {
        const districtList = address.filter((x)=>x.province === initProvince)[0].districtsArr;
        return districtList.map((item)=>({
                value: item,
                label: item
            }));
    }
    (0,external_react_.useEffect)(()=>{
        const newDistrictList = getAndFormatDistrict();
        setDistrict(newDistrictList);
    }, [
        initProvince
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-3 flex-col mb-5",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col md:flex-row justify-between gap-5",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "md:w-[50%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "font-semibold",
                                children: "Tỉnh/Th\xe0nh phố *"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_select_default()), {
                                placeholder: "Vui l\xf2ng chọn Tỉnh/Th\xe0nh phố",
                                defaultInputValue: initProvince,
                                name: "Provice",
                                options: formatProvince,
                                onChange: (e)=>setProvince(e.value)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "md:w-[50%]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "font-semibold",
                                children: "Quận/Huyện *"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_select_default()), {
                                placeholder: "Vui l\xf2ng chọn Quận/Huyện",
                                options: district,
                                onChange: (e)=>setDistrictName(e.value)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(PaymetnInputForm, {
                label: "Địa chỉ",
                placeHolder: "Vui l\xf2ng nhập Địa chỉ cụ thể"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Payment/PaymentUserInfo.tsx



function PaymentUserInfo() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 md:gap-5",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymetnInputForm, {
                        label: "T\xean *",
                        placeHolder: "Vui l\xf2ng nhập t\xean"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymetnInputForm, {
                        label: "Họ *",
                        placeHolder: "Vui l\xf2ng nhập họ"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymetnInputForm, {
                        label: "Số điện thoại *",
                        placeHolder: "Vui l\xf2ng nhập số điện thoại"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymetnInputForm, {
                        label: "Email *",
                        placeHolder: "Vui l\xf2ng nhập email"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-bold mt-6 mb-2 underline",
                        children: "Địa chỉ nhận h\xe0ng"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymentAddress, {})
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Payment/Payment.tsx



function Payment() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row w-full md:w-2/3 my-4 md:my-10 mx-[auto] gap-5 ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:w-2/3 p-2 md:p-4 bg-gray-100 rounded-lg shadow-[0_3px_8px_rgba(0,0,0,0.3)]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "font-bold mb-3",
                        children: [
                            "VUI L\xd2NG HO\xc0N TH\xc0NH TH\xd4NG TIN ĐẶT H\xc0NG",
                            " "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymentUserInfo, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymentMethod, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:w-1/3",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "sticky top-[80px] bg-gray-100 rounded-lg min-h-[80px] p-4 shadow-[0_3px_8px_rgba(0,0,0,0.3)]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-[700] text-[#891b1c] text-[1.3rem]",
                            children: "ĐƠN H\xc0NG CỦA BẠN"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                            className: "w-full mt-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "uppercase text-left border-b-2 border-slate-400",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                colSpan: 2,
                                                children: "Sản phẩm"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                className: "text-right",
                                                children: "Tạm t\xednh"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "border-b-[1px] border-slate-300 ",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    colSpan: 2,
                                                    className: "py-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "T\xean sản phẩm"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: " x 3"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "text-right",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-[0.8rem] font-bold",
                                                            children: "₫"
                                                        }),
                                                        901234..toLocaleString("en-US")
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "border-b-[1px] border-slate-300 ",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    colSpan: 2,
                                                    className: "py-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "T\xean sản phẩm"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: " x 3"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "text-right",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-[0.8rem] font-bold",
                                                            children: "₫"
                                                        }),
                                                        901234..toLocaleString("en-US")
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "border-b-[1px] border-slate-300 ",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    colSpan: 2,
                                                    className: "py-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "T\xean sản phẩm"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: " x 3"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                    className: "text-right",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-[0.8rem] font-bold",
                                                            children: "₫"
                                                        }),
                                                        901234..toLocaleString("en-US")
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between mt-4 border-b-[1px] border-slate-400 pb-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "font-bold",
                                    children: "Ph\xed giao h\xe0ng"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-[0.8rem] font-bold",
                                            children: "₫"
                                        }),
                                        10000..toLocaleString("en-US")
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between border-b-2 border-slate-400 font-bold text-[1.3rem] mt-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Tổng"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-[0.8rem]",
                                            children: "₫"
                                        }),
                                        901231234..toLocaleString("en-US")
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-gray-700 mt-3 text-white text-center py-2 rounded-[30px] hover:bg-gray-900 hover:cursor-pointer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-bold",
                                onClick: ()=>{},
                                children: "Đặt h\xe0ng"
                            })
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Payment/index.ts



;// CONCATENATED MODULE: ./pages/payment.tsx


function PaymentPage() {
    return /*#__PURE__*/ jsx_runtime_.jsx(Payment, {});
}


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7786));
module.exports = __webpack_exports__;

})();