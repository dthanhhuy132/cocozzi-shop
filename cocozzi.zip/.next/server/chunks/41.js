"use strict";
exports.id = 41;
exports.ids = [41];
exports.modules = {

/***/ 9684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "T": () => (/* reexport */ Logo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/images/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.62890bb1.png","height":791,"width":3635,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAARUlEQVR4nA3JMQ5AQBRF0ft+JAhjKguwB5UF2qZGoxflf6Y7yVEp9UDsmb5Cuo0Hmw6coE3TvJyCN+01Qk/LCowSX3P/A+FpFjb0U8PfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./components/Logo/Logo.tsx




function Logo({ width ="150" , height ="30"  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "/",
        className: "block center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: logo,
                alt: "Picture of the author",
                width: width,
                height: height
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/Logo/index.ts



/***/ }),

/***/ 6452:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const baseURL = process.env.DEVELOPMENT_ENV;
const api = {
    call () {
        return axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
            baseURL,
            headers: {
            }
        });
    },
    callWithToken (token) {
        return axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
            baseURL,
            headers: {
                // 'Content-type': 'application/json',
                Authorization: "Bearer " + token
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (api);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;