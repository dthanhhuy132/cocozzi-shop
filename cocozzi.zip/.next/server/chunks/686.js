"use strict";
exports.id = 686;
exports.ids = [686];
exports.modules = {

/***/ 8211:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "G": () => (/* reexport */ HomeBackground)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./public/images/home/1.jpg
var _1 = __webpack_require__(4602);
// EXTERNAL MODULE: ./public/images/home/2.jpg
var _2 = __webpack_require__(7043);
// EXTERNAL MODULE: ./public/images/home/3.jpg
var _3 = __webpack_require__(8527);
// EXTERNAL MODULE: ./public/images/home/4.jpg
var _4 = __webpack_require__(7989);
;// CONCATENATED MODULE: ./components/HomeBackground/HomeBackground.tsx









const ImageArr = [
    _1/* default */.Z,
    _2/* default */.Z,
    _3/* default */.Z,
    _4/* default */.Z
];
function HomeBackground({ ishomepage =true  }) {
    const router = (0,router_.useRouter)();
    const { 0: isActiveAnimation , 1: setIsActiveAnimation  } = (0,external_react_.useState)(0);
    const changeImageActiveAnimate = ()=>{
        if (isActiveAnimation < ImageArr.length - 1) {
            setIsActiveAnimation((pre)=>pre + 1);
        } else {
            setIsActiveAnimation(0);
        }
    };
    const handleClickImage = ()=>{
        if (ishomepage) {
            router.push("/product/124");
        } else {
            return;
        }
    };
    (0,external_react_.useEffect)(()=>{
        const intervalId = setInterval(changeImageActiveAnimate, 4000);
        return ()=>clearInterval(intervalId);
    }, [
        isActiveAnimation
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 md:grid-cols-2 gap-0",
        children: ImageArr.map((imageSrc, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                onClick: ()=>handleClickImage(),
                children: /*#__PURE__*/ jsx_runtime_.jsx(ImageSC, {
                    src: imageSrc,
                    active: isActiveAnimation === index ? "1" : "",
                    ishomepage: ishomepage ? "1" : "",
                    layout: "responsive",
                    objectFit: "cover"
                })
            }, index))
    });
}
const lighting = external_styled_components_.keyframes`
   0% {
      filter: brightness(1)
   }
   50% {
      filter: brightness(1.2)
   }
   100% {
      filter: brightness(1)
   }
`;
const ImageSC = external_styled_components_default()((image_default())).withConfig({
    componentId: "sc-74e50f6b-0"
})((props)=>external_styled_components_.css`
      animation: ${props.active && props.ishomepage && external_styled_components_.css`1s linear ${lighting}`};

      animation-timing-function: linear;
      transition: all 0.3s linear;
      transform: 'scale(1.01)';

      &:hover {
         transform: ${props.ishomepage && "scale(1.1)"};
         z-index: 9;
         border: 10px solid red;
         box-sizing: content-box;
      }
   `);

;// CONCATENATED MODULE: ./components/HomeBackground/index.ts



/***/ }),

/***/ 8472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "m3": () => (/* reexport */ Login),
  "tl": () => (/* reexport */ LoginValidationText),
  "JX": () => (/* reexport */ SocialLogin)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
;// CONCATENATED MODULE: ./components/Login/validateSchema.ts

const validateLoginSchema = {
    email: external_yup_.string().email("Invalid email format").required("Please enter your email!"),
    password: external_yup_.string().min(8, "Minimum 8 characters").required("Please enter your password!")
};
const validateRegisterSchema = {
    email: external_yup_.string().email("Invalid email format").required("Please enter your email!"),
    password: external_yup_.string().min(8, "Minimum 8 characters").required("Please enter your password!"),
    repassword: external_yup_.string().oneOf([
        external_yup_.ref("password")
    ], "Password's not match").required("Please enter re-password")
};


;// CONCATENATED MODULE: ./components/common/Loading.tsx

function Loading() {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        xmlnsXlink: "http://www.w3.org/1999/xlink",
        style: {
            margin: "auto",
            background: "transparent",
            display: "block"
        },
        width: "20px",
        height: "20px",
        viewBox: "0 0 100 100",
        preserveAspectRatio: "xMidYMid",
        children: /*#__PURE__*/ jsx_runtime_.jsx("circle", {
            cx: 50,
            cy: 50,
            fill: "none",
            stroke: "#eff2f3",
            strokeWidth: 10,
            r: 35,
            strokeDasharray: "164.93361431346415 56.97787143782138",
            children: /*#__PURE__*/ jsx_runtime_.jsx("animateTransform", {
                attributeName: "transform",
                type: "rotate",
                repeatCount: "indefinite",
                dur: "1s",
                values: "0 50 50;360 50 50",
                keyTimes: "0;1"
            })
        })
    });
}

;// CONCATENATED MODULE: ./components/common/index.ts


;// CONCATENATED MODULE: ./components/Login/Login.tsx










function Login({ formValue , handleSubmitForm , isShowLoading =false , errorText =""  }) {
    console.log("form value trong register la gi", formValue);
    const router = (0,router_.useRouter)();
    const yupFormValidateSchema = router.pathname === "/register" ? validateRegisterSchema : validateLoginSchema;
    const formik = (0,external_formik_.useFormik)({
        initialValues: formValue,
        validationSchema: external_yup_.object(yupFormValidateSchema),
        onSubmit: (values)=>{
            handleSubmitForm(values);
        }
    });
    const isRegisterPage = (0,external_react_.useMemo)(()=>router.pathname === "/register", [
        router.pathname
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relattive w-[350px] mt-10 p-10 border-1 bg-red-700 rounded-md md:w-[400px] md:rounded-lg md:p-5 lg:w-[450px] lg:p-10 ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        autoComplete: "off",
                        onSubmit: formik.handleSubmit,
                        className: "w-full mb-4 flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        name: "email",
                                        placeholder: "email",
                                        className: "w-full text-white outline-none bg-transparent border-b-[2px] border-black pb-[4px] mb-2 placeholder-gray-900 placeholder:uppercase",
                                        value: formik.values.email,
                                        onChange: formik.handleChange
                                    }),
                                    formik.errors.email && formik.touched.email && /*#__PURE__*/ jsx_runtime_.jsx(LoginValidationText, {
                                        warningText: formik.errors.email
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "password",
                                        name: "password",
                                        placeholder: "password",
                                        className: "w-full text-white bg-[none] outline-none bg-transparent border-b-[2px] border-black pb-[4px] mb-2 placeholder-gray-900 placeholder:uppercase",
                                        value: formik.values.password,
                                        onChange: formik.handleChange
                                    }),
                                    formik.errors.password && formik.touched.password && /*#__PURE__*/ jsx_runtime_.jsx(LoginValidationText, {
                                        warningText: formik.errors.password
                                    })
                                ]
                            }),
                            isRegisterPage && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "password",
                                        name: "repassword",
                                        placeholder: "re-password",
                                        className: "w-full text-white bg-[none] outline-none bg-transparent border-b-[2px] border-black pb-[4px] mb-2 placeholder-gray-900 placeholder:uppercase",
                                        value: formik.values.repassword,
                                        onChange: formik.handleChange
                                    }),
                                    formik.errors.repassword && formik.touched.repassword && /*#__PURE__*/ jsx_runtime_.jsx(LoginValidationText, {
                                        warningText: formik.errors.repassword
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                type: "submit",
                                disabled: isShowLoading,
                                className: `disabled:hover:bg-[#b91c1c] flex justify-center border-[1px] border-black rounded-lg uppercase text-[0.9rem] font-[400] text-white py-2 mt-3 mb-2 hover:bg-[#b91c1c] ${!isShowLoading && "hover:brightness-125"}`,
                                children: [
                                    isShowLoading && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mr-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Loading, {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: isRegisterPage ? "Register" : "Login"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center",
                                children: errorText && /*#__PURE__*/ jsx_runtime_.jsx(LoginValidationText, {
                                    warningText: errorText,
                                    isError: errorText ? true : false
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-center",
                        children: isRegisterPage ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "font-semibold",
                            children: [
                                "Đ\xe3 c\xf3 t\xe0i khoản",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-900 pl-1 hover:text-blue-600",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/membership",
                                        children: "Đăng nhập"
                                    })
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "font-semibold",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-900 pr-1 hover:text-blue-600",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/register",
                                        children: "Đăng k\xed"
                                    })
                                }),
                                "một t\xe0i khoản"
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "mt-5 text-white text-[0.9rem]",
                children: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sed mollitia recusandae iste ad assumenda culpa incidunt iusto maxime voluptate neque?"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SocialLogin, {})
        ]
    });
}

;// CONCATENATED MODULE: ./components/Login/LoginValidateText.tsx

function LoginValidationText({ warningText , isError =false  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
        className: `text-white ${isError ? "text-[1rem] italic" : "text-[0.8rem]"} font-thin`,
        children: [
            "* ",
            warningText
        ]
    });
}

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./components/Login/SocialLogin.tsx



function SocialLogin() {
    // login with google
    const { data: session  } = (0,react_.useSession)();
    function handleSignInWithGoogle() {
        (0,react_.signIn)("google");
    }
    (0,external_react_.useEffect)(()=>{
        if (session) {}
    }, [
        session
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-2 mt-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "uppercase text-center font-bold text-white ",
                children: [
                    "Tiếp tục với",
                    " "
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "relative p-2 text-center bg-white cursor-pointer rounded-sm hover:bg-slate-300",
                onClick: handleSignInWithGoogle,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "https://www.freepnglogos.com/uploads/google-logo-png/google-logo-png-suite-everything-you-need-know-about-google-newest-0.png",
                        className: "absolute top-[50%] left-2 translate-y-[-50%] w-[18px] h-[18px]",
                        alt: "gg-icon"
                    }),
                    "Tiếp tục với google"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "relative p-2 text-center bg-white cursor-pointer rounded-sm hover:bg-slate-300",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Facebook_icon_2013.svg/640px-Facebook_icon_2013.svg.png",
                        className: "absolute top-[50%] left-2 translate-y-[-50%] w-[18px] h-[18px]",
                        alt: "fb-icon"
                    }),
                    "Tiếp tục với facebook"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "relative p-2 text-center bg-white cursor-pointer rounded-sm hover:bg-slate-300",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "https://cdn3.iconfinder.com/data/icons/picons-social/57/56-apple-512.png",
                        className: "absolute top-[50%] left-2 translate-y-[-50%] w-[18px] h-[18px]",
                        alt: "ap-icon"
                    }),
                    "Tiếp tục với apple"
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Login/index.ts





/***/ })

};
;