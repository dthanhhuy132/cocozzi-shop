"use strict";
exports.id = 444;
exports.ids = [444];
exports.modules = {

/***/ 4229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/5.6f0e8c58.webp","height":660,"width":500,"blurDataURL":"data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAADwAQCdASoGAAgAAkA4JQBOgCHcyrv/tYAA/rXhSLLP5CEl5zs9Efo1bsyYSwylRlmZnHAnYPUwAA==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 5771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/6.c0de9bf2.webp","height":660,"width":500,"blurDataURL":"data:image/webp;base64,UklGRkoAAABXRUJQVlA4ID4AAACwAQCdASoGAAgAAkA4JZwAApzbxhx8AP7or1uEP+zj9DzG8Cv06WPjRzKfURrIy6ryLwatB5eVxiIB0swAAA==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 3588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/7.934ee116.webp","height":660,"width":500,"blurDataURL":"data:image/webp;base64,UklGRlIAAABXRUJQVlA4IEYAAAAQAgCdASoGAAgAAkA4JYgCdH8AGMKIDh1AAM4/U+ExxR2p9G13p1sDOmWvmTapemWokur+ZarYfULAVfFDezEgXiG/o4AA","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 4394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/8.9a011e94.webp","height":660,"width":500,"blurDataURL":"data:image/webp;base64,UklGRkQAAABXRUJQVlA4IDgAAACwAQCdASoGAAgAAkA4JZwAApzURLdwAP70Fuuhobjr+q/3uBcqG/DLuGY8YtlkqE1NzhHulmAAAA==","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 5028:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "C": () => (/* reexport */ ProductItem)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/ProductItem/ProductItem.tsx



function ProductItem({ img , displayPrice =false  }) {
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "p-2 md:px-2 transition hover:border-2 hover:border-[#891b1c] rounded-lg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "cursor-pointer rounded-md overflow-hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "transition hover:scale-[1.1] ",
                    src: img,
                    alt: "",
                    onClick: ()=>router.push("/product/123")
                })
            }),
            displayPrice && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between px-2 text-[0.9rem] md:text-[1rem]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "Product name"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "$50"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "fa-solid fa-cart-plus text-[1.2rem] text-gray-500 hover:text-[#891b1c] cursor-pointer mt-1"
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/ProductItem/index.ts



/***/ })

};
;