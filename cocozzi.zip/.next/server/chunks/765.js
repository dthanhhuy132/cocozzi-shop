"use strict";
exports.id = 765;
exports.ids = [765];
exports.modules = {

/***/ 9664:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Nh": () => (/* reexport */ Bag),
  "ex": () => (/* reexport */ BagHeader),
  "od": () => (/* reexport */ BagHover),
  "Zi": () => (/* reexport */ BagItem)
});

// UNUSED EXPORTS: BagItemHover, InputQuantity

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./store/cart/cartSlice.ts
var cartSlice = __webpack_require__(5219);
;// CONCATENATED MODULE: ./components/Bag/Bag.tsx






function Bag({ carts  }) {
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        dispatch((0,cartSlice/* updateCart */.x)(carts));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row w-full md:w-2/3 my-4 md:my-10 mx-[auto] gap-5 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:w-2/3 p-2 md:p-4 bg-gray-100 rounded-lg shadow-[0_3px_8px_rgba(0,0,0,0.3)]",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    className: "w-full border-separate border-spacing-y-[10px]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                            className: "font-thin text-[0.95rem]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BagHeader, {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                            className: "p-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(BagItem, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(BagItem, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(BagItem, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(BagItem, {})
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:w-1/3",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "sticky top-[80px] bg-gray-100 rounded-lg min-h-[80px] p-4 shadow-[0_3px_8px_rgba(0,0,0,0.3)]",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between border-b-2 border-slate-400 font-bold text-[1.3rem]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Tổng"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "pr-1",
                                            children: "₫"
                                        }),
                                        901231234..toLocaleString("en-US")
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-gray-700 mt-3 text-white text-center py-2 rounded-[30px] hover:bg-gray-900 hover:cursor-pointer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-bold",
                                onClick: ()=>router.push("/payment"),
                                children: "Tiến h\xe0nh thanh to\xe1n"
                            })
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./hooks/UseWindowDimensions.ts
var UseWindowDimensions = __webpack_require__(4231);
;// CONCATENATED MODULE: ./components/Bag/InputQuantity.tsx


function InputQuantity({ min =1 , max =20  }) {
    const { 0: count , 1: setCount  } = (0,external_react_.useState)(min);
    function handleClickAdd() {
        if (count < max) {
            setCount(count + 1);
        // onCountChange(count + 1);
        }
    }
    function handleClickSubtract() {
        if (count > min) {
            setCount(count - 1);
        // onCountChange(count - 1);
        }
    }
    function handleClick(e) {
        setCount(e.target.valueAsNumber);
    // onCountChange(e.target.valueAsNumber);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative border-2 border-gray-300 md:py-[4px] rounded-[20px] text-center whitespace-nowrap overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                onClick: handleClickSubtract,
                className: "absolute top-[45%] translate-y-[-50%] left-0 text-[1.2rem] font-bold pl-[10px] pr-[6px] py-4 hover:bg-gray-300",
                children: "-"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: "input-quantity outline-none text-center bg-transparent text-[#ca282a] w-[40px]",
                type: "number",
                min: min,
                max: max,
                value: count,
                onChange: (e)=>setCount(e.target.value)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                onClick: handleClickAdd,
                className: "absolute top-[45%] translate-y-[-50%] right-0 font-bold pr-2 pl-[6px] py-4 hover:bg-gray-300 flex justify-center items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "+"
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Bag/BagItem.tsx




function BagItem() {
    const { isMobile  } = (0,UseWindowDimensions/* default */.Z)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "border-b pb-3 border-slate-300 ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex gap-2 items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineCloseCircle, {
                                className: "text-[1.3rem] text-gray-400 hover:cursor-pointer hover:text-gray-900"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQLG2aQbb_A6E3JwO29d76XyJRbxWIo6nUqhe-93DDIr7g4u96ZMVBLybnsxzOd3pJCQ0&usqp=CAU",
                            alt: "",
                            className: "w-[100px] md:w-[120px] rounded-md"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `${isMobile && "flex flex-col flex-1 gap-1"}`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "md:min-w-[200px] md:max-w-[200px] text-[0.9rem]",
                                    children: "day la ten san pha fasdf asdfm"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: `${!isMobile && "hidden"} flex items-center justify-between gap-2`,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "flex items-start",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mr-1",
                                                    children: "2 x "
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "₫"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-bold",
                                                    children: 5000000..toLocaleString("en-US")
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-[35%]",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(InputQuantity, {})
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: `${isMobile && "hidden"} px-5 font-bold border-b pb-3 border-slate-300`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "flex items-start",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "₫"
                        }),
                        5000000..toLocaleString("en-US")
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: `${isMobile && "hidden"} px-5 border-b pb-3 border-slate-300`,
                children: /*#__PURE__*/ jsx_runtime_.jsx(InputQuantity, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: `${isMobile && "hidden"} px-5 font-bold border-b pb-3 border-slate-300`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "flex items-start",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "₫"
                        }),
                        5000..toLocaleString("en-US")
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Bag/BagHeader.tsx


function BagHeader() {
    const { isMobile  } = (0,UseWindowDimensions/* default */.Z)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
        className: "uppercase",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                className: "text-left border-b-[2px] border-slate-400",
                children: "Sản phẩm"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                className: `${isMobile && "hidden"} text-left border-b-[2px] border-slate-400 px-5`,
                children: "Gi\xe1"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                className: `${isMobile && "hidden"} text-left border-b-[2px] border-slate-400 px-5 whitespace-nowrap`,
                children: "Số lượng"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                className: `${isMobile && "hidden"} text-left border-b-[2px] border-slate-400 px-5 whitespace-nowrap`,
                children: "Tạm t\xednh"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./public/images/shop/1.webp
var _1 = __webpack_require__(9907);
// EXTERNAL MODULE: ./public/images/shop/2.webp
var _2 = __webpack_require__(7866);
// EXTERNAL MODULE: ./public/images/shop/3.webp
var _3 = __webpack_require__(6935);
// EXTERNAL MODULE: ./public/images/shop/4.webp
var _4 = __webpack_require__(2248);
;// CONCATENATED MODULE: ./components/Bag/BagItemHover.tsx

function BagItemHover() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQLG2aQbb_A6E3JwO29d76XyJRbxWIo6nUqhe-93DDIr7g4u96ZMVBLybnsxzOd3pJCQ0&usqp=CAU",
                        alt: "",
                        className: "w-[70px] md:w-[90px] object-cover rounded-md"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "capitalize text-[0.85rem] font-thin",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "T\xean sản phẩm T\xean sản phẩmT\xean sản phẩmT\xean sản phẩm"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "lowercase",
                                children: "x 2"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mr-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "font-semibold",
                    children: 5000000..toLocaleString("en-US")
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Bag/BagHover.tsx








const imgArr = [
    _1/* default */.Z,
    _2/* default */.Z,
    _3/* default */.Z,
    _4/* default */.Z
];
function BagHover() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DivSC, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative flex flex-col justify-end z-10 p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "border-b-2 lowercase mb-2 font-thin pb-2",
                        children: "shopping bag"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-col gap-4 my-2 max-h-[170px] overflow-auto",
                        children: imgArr.map((img, index)=>// add img here
                            /*#__PURE__*/ jsx_runtime_.jsx(BagItemHover, {}, index))
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "border-t-2 mt-2 lowercase text-center",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between font-thin mt-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Total"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "3 000 000"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/payment",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "w-[50%] font-bold bg-[white] text-black rounded-[30px] pb-1 mx-[auto] mt-2 cursor-pointer",
                                    children: "pay"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(DivSCBackground, {})
        ]
    });
}
const DivSC = external_styled_components_default()("div").withConfig({
    componentId: "sc-b4e8c196-0"
})`
   position: absolute;
   top: 30px;
   right: 0;

   width: 350px;
   min-height: 320px;

   border-radius: 5px;

   color: white;

   cursor: default;

   &:after {
      content: '';
      position: absolute;
      top: -12px;
      right: 4px;
      border-width: 6px;
      border-style: solid;
      border-color: transparent transparent black transparent;
      filter: unset;
   }

   &:before {
      content: '';
      position: absolute;
      top: -7px;
      left: 0;
      width: 100%;
      height: 30px;

      background-color: transparent;
   }
`;
const DivSCBackground = external_styled_components_default()(DivSC).withConfig({
    componentId: "sc-b4e8c196-1"
})`
   background-image: url('https://images.pond5.com/shopping-cart-background-presentation-footage-075835137_prevstill.jpeg');

   background-size: cover;
   background-repeat: no-repeat;
   z-index: 1;
   top: 0;
   right: 0;
   bottom: 0;
   left: 0;

   width: 100%;
   height: 100%;

   filter: brightness(0.25);
`;

;// CONCATENATED MODULE: ./components/Bag/index.ts








/***/ }),

/***/ 4231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useWindowDimensions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useWindowDimensions() {
    const hasWindow = "undefined" !== "undefined";
    function getWindowDimensions() {
        const width = hasWindow ? window.innerWidth : null;
        const height = hasWindow ? window.innerHeight : null;
        let isMobile;
        if (width && width < 600) {
            isMobile = true;
        } else {
            isMobile = false;
        }
        return {
            width,
            height,
            isMobile
        };
    }
    const { 0: windowDimensions , 1: setWindowDimensions  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getWindowDimensions());
    function handleResize() {
        setWindowDimensions(getWindowDimensions());
    }
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (hasWindow) {
            window.addEventListener("resize", handleResize);
            return ()=>window.removeEventListener("resize", handleResize);
        }
    }, [
        hasWindow
    ]);
    return windowDimensions;
}


/***/ })

};
;