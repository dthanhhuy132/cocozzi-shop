"use strict";
exports.id = 725;
exports.ids = [725];
exports.modules = {

/***/ 2490:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mi": () => (/* binding */ getTokenExpireTime),
/* harmony export */   "aj": () => (/* binding */ parseJwt),
/* harmony export */   "v8": () => (/* binding */ getTokenSSRAndCSS)
/* harmony export */ });
/* harmony import */ var atob__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(887);
/* harmony import */ var atob__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(atob__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_2__]);
js_cookie__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const parseJwt = (token)=>{
    try {
        let base64Url = token.split(".")[1];
        let base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        let jsonPayload = decodeURIComponent(atob__WEBPACK_IMPORTED_MODULE_0___default()(base64).split("").map(function(c) {
            return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(""));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
};
const getTokenSSRAndCSS = (ctx)=>{
    let token = "";
    let userToken = null;
    if (true) {
        var ref, ref1;
        // SSR
        const cookieStr = (ctx === null || ctx === void 0 ? void 0 : (ref = ctx.req) === null || ref === void 0 ? void 0 : (ref1 = ref.headers) === null || ref1 === void 0 ? void 0 : ref1.cookie) || "";
        token = cookie__WEBPACK_IMPORTED_MODULE_1___default().parse(cookieStr).token;
        userToken = parseJwt(token);
    } else {}
    return [
        token,
        userToken
    ];
};
const getTokenExpireTime = (token)=>{
    const expireTokenTime = parseJwt(token).exp;
    const currentTime = new Date().getTime() / 1000;
    const expireTokenDay = (expireTokenTime - currentTime) / 60 / 60 / 24;
    return expireTokenDay;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9172:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6452);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api__WEBPACK_IMPORTED_MODULE_0__]);
_api__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const authApi = {
    login: (loginData)=>{
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].call */ .Z.call().post("/auth/login", loginData);
    },
    register: (registerData)=>{
        return _api__WEBPACK_IMPORTED_MODULE_0__/* ["default"].call */ .Z.call().post("/auth/login", registerData);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authApi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9136:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ loginAsyncAction)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _service_authApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9172);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_service_authApi__WEBPACK_IMPORTED_MODULE_1__]);
_service_authApi__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const loginAsyncAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("auth/login", async (loginData)=>{
    try {
        const response = await _service_authApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].login */ .Z.login(loginData);
        return {
            ok: true,
            user: response.data.data
        };
    } catch (error) {
        return {
            ok: false,
            message: error.response.data.message
        };
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7692:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export logout */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _authAsyncAction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9136);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9915);
/* harmony import */ var _helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authAsyncAction__WEBPACK_IMPORTED_MODULE_1__, js_cookie__WEBPACK_IMPORTED_MODULE_2__, _helper__WEBPACK_IMPORTED_MODULE_3__]);
([_authAsyncAction__WEBPACK_IMPORTED_MODULE_1__, js_cookie__WEBPACK_IMPORTED_MODULE_2__, _helper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const token = js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].get("token");
const user = (0,_helper__WEBPACK_IMPORTED_MODULE_3__/* .parseJwt */ .aj)(token);
const initialState = {
    user,
    token
};
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        logout: (state)=>{
            js_cookie__WEBPACK_IMPORTED_MODULE_2__["default"].remove("token");
            state.user = {};
            state.token = "";
        }
    },
    extraReducers: {
        [_authAsyncAction__WEBPACK_IMPORTED_MODULE_1__/* .loginAsyncAction.fulfilled */ .W.fulfilled]: (state, action)=>{
            var ref, ref1, ref2, ref3;
            state.user = (ref = action.payload) === null || ref === void 0 ? void 0 : (ref1 = ref.user) === null || ref1 === void 0 ? void 0 : ref1.user;
            state.token = (ref2 = action.payload) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.user) === null || ref3 === void 0 ? void 0 : ref3.accessToken;
        }
    }
});
const { logout  } = authSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5219:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "x": () => (/* binding */ updateCart)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    cart: []
};
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        updateCart: (state, action)=>{
            state.cart = action.payload;
        }
    }
});
const { updateCart  } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);


/***/ }),

/***/ 8953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export updateCategory */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    categories: []
};
const categorySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        updateCategory: (state, action)=>{
            state.categories = action.payload;
        }
    }
});
const { updateCategory  } = categorySlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (categorySlice.reducer);


/***/ }),

/***/ 4664:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _auth_authSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7692);
/* harmony import */ var _cart_cartSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5219);
/* harmony import */ var _category_categorySlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8953);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth_authSlice__WEBPACK_IMPORTED_MODULE_2__]);
_auth_authSlice__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        auth: _auth_authSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
        cart: _cart_cartSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
        categories: _category_categorySlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z
    }
});
const useAppDispatch = react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;