export default function InfoPage() {
   return <>this is info page</>;
}
