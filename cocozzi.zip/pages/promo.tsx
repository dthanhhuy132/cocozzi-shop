export default function PromoPage() {
   return <>This is promo page</>;
}
