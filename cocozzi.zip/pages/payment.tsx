import {Payment} from '../components/Payment';

export default function PaymentPage() {
   return <Payment />;
}
