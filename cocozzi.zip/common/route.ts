const route = {
   shop: '/shop',
   membership: '/membership',
   
}

export default route